# Winter Arc Protocol — Firestore Security Specification

## 1. Data Invariants
1. **User Isolation (`UserProgress`)**: A `/users/{userId}` document can only be read, created, updated, or deleted by the authenticated owner whose `request.auth.uid == userId` and `data.userId == request.auth.uid`.
2. **Meal Ownership (`MealEntry`)**: A `/users/{userId}/meals/{mealId}` document can only be read, created, updated, or deleted when `request.auth.uid == userId` and `data.userId == request.auth.uid`.
3. **Immutable Metadata**: `userId` and `createdAt` cannot be modified after creation (`incoming().userId == existing().userId && incoming().createdAt == existing().createdAt`).
4. **Strict Bounds & Enums**:
   - `waterIntakeMl` must be an integer in `0..10000`.
   - `completedSets` must be a bounded list (`size() <= 100`).
   - `completedCalendarDays` must be a bounded list (`size() <= 35`).
   - `category` must be one of `'BREAKFAST'`, `'LUNCH'`, `'PRE_WORKOUT'`, `'POST_WORKOUT'`, `'DINNER'`.
   - `status` must be one of `'EATEN'`, `'SKIPPED'`, `'PLANNED'`.
   - `calories` in `0..5000`, `proteinGrams` in `0..500`, `carbsGrams` in `0..1000`, `fatsGrams` in `0..500`.

## 2. The "Dirty Dozen" Adversarial Payloads
1. **Unauthenticated Read**: `unauthDb.collection("users").doc("alice").get()` -> Reject
2. **Cross-User Profile Read**: `bobDb.collection("users").doc("alice").get()` -> Reject
3. **Cross-User Meal List**: `bobDb.collection("users").doc("alice").collection("meals").get()` -> Reject
4. **Identity Spoofing on Create**: Alice creates `/users/alice/meals/m1` with `userId: "bob"` -> Reject
5. **Shadow Update (Ghost Field)**: Alice updates `/users/alice` with `{ isAdmin: true }` -> Reject
6. **Immutable `createdAt` Tampering**: Alice updates `createdAt` on `/users/alice/meals/m1` -> Reject
7. **Immutable `userId` Transfer**: Alice updates `userId` on `/users/alice/meals/m1` to `"bob"` -> Reject
8. **Negative Calorie Injection**: Alice creates a meal with `calories: -500` -> Reject
9. **Invalid Meal Status Enum**: Alice updates meal status to `"DELETED_BY_HACK"` -> Reject
10. **Oversized String Resource Poisoning**: Alice sets `name` to a 500-char string -> Reject
11. **Unbounded Array Injection**: Alice sets `completedSets` to 150 items -> Reject
12. **Future Timestamp Spoofing**: Alice sets `createdAt` to `request.time + 1 hour` -> Reject
