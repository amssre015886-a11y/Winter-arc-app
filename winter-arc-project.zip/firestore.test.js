const {
  initializeTestEnvironment,
  assertFails,
  assertSucceeds,
} = require("@firebase/rules-unit-testing");
const { test, before, after, beforeEach } = require("node:test");
const fs = require("node:fs");

let testEnv;
const PROJECT_ID = process.env.GCP_PROJECT || "demo-no-project";
const ALICE_UID = "alice_123";
const BOB_UID = "bob_456";

const [emulatorHost, emulatorPortStr] = (
  process.env.FIRESTORE_EMULATOR_HOST || "127.0.0.1:8085"
).split(":");
const emulatorPort = parseInt(emulatorPortStr, 10);

before(async () => {
  const rules = fs.readFileSync("./firestore.rules", "utf8");
  testEnv = await initializeTestEnvironment({
    projectId: PROJECT_ID,
    firestore: {
      rules,
      host: emulatorHost,
      port: emulatorPort,
    },
  });
});

after(async () => {
  if (testEnv) {
    await testEnv.cleanup();
  }
});

beforeEach(async () => {
  if (testEnv) {
    await testEnv.clearFirestore();
  }
});

test("Unauthenticated user: cannot read or write user progress or meals", async () => {
  const unauthDb = testEnv.unauthenticatedContext().firestore();
  await assertFails(unauthDb.collection("users").doc(ALICE_UID).get());
  await assertFails(
    unauthDb.collection("users").doc(ALICE_UID).collection("meals").get()
  );
});

test("Authenticated user: can create and read own UserProgress", async () => {
  const aliceDb = testEnv.authenticatedContext(ALICE_UID).firestore();
  const now = new Date();
  await assertSucceeds(
    aliceDb.collection("users").doc(ALICE_UID).set({
      userId: ALICE_UID,
      displayName: "Alice Athlete",
      waterIntakeMl: 1500,
      completedSets: ["sun_ex_1_0", "sun_ex_1_1"],
      completedCalendarDays: [1, 2],
      createdAt: now,
      updatedAt: now,
    })
  );
  await assertSucceeds(aliceDb.collection("users").doc(ALICE_UID).get());
});

test("Authenticated user: cannot read or modify another user's progress", async () => {
  const now = new Date();
  await testEnv.withSecurityRulesDisabled(async (context) => {
    await context.firestore().collection("users").doc(BOB_UID).set({
      userId: BOB_UID,
      displayName: "Bob",
      waterIntakeMl: 1000,
      completedSets: [],
      completedCalendarDays: [1],
      createdAt: now,
      updatedAt: now,
    });
  });

  const aliceDb = testEnv.authenticatedContext(ALICE_UID).firestore();
  await assertFails(aliceDb.collection("users").doc(BOB_UID).get());
  await assertFails(
    aliceDb.collection("users").doc(BOB_UID).update({ waterIntakeMl: 2000, updatedAt: new Date() })
  );
});

test("Authenticated user: can create, list, and update own MealEntry", async () => {
  const aliceDb = testEnv.authenticatedContext(ALICE_UID).firestore();
  const now = new Date();
  const mealRef = aliceDb
    .collection("users")
    .doc(ALICE_UID)
    .collection("meals")
    .doc("meal_1");

  await assertSucceeds(
    mealRef.set({
      userId: ALICE_UID,
      name: "100g Paneer Bhurji",
      category: "LUNCH",
      calories: 265,
      proteinGrams: 18,
      carbsGrams: 4,
      fatsGrams: 20,
      status: "EATEN",
      isCustom: true,
      createdAt: now,
      updatedAt: now,
    })
  );

  await assertSucceeds(
    aliceDb
      .collection("users")
      .doc(ALICE_UID)
      .collection("meals")
      .where("userId", "==", ALICE_UID)
      .get()
  );

  await assertSucceeds(
    mealRef.update({
      status: "SKIPPED",
      updatedAt: new Date(),
    })
  );
});

test("Shadow update with ghost field or invalid enum is rejected", async () => {
  const now = new Date();
  await testEnv.withSecurityRulesDisabled(async (context) => {
    await context
      .firestore()
      .collection("users")
      .doc(ALICE_UID)
      .collection("meals")
      .doc("meal_1")
      .set({
        userId: ALICE_UID,
        name: "Boiled Eggs",
        category: "BREAKFAST",
        calories: 280,
        proteinGrams: 24,
        carbsGrams: 2,
        fatsGrams: 20,
        status: "PLANNED",
        isCustom: false,
        createdAt: now,
        updatedAt: now,
      });
  });

  const aliceDb = testEnv.authenticatedContext(ALICE_UID).firestore();
  const mealRef = aliceDb
    .collection("users")
    .doc(ALICE_UID)
    .collection("meals")
    .doc("meal_1");

  // Ghost field
  await assertFails(
    mealRef.update({
      status: "EATEN",
      isVerified: true,
      updatedAt: new Date(),
    })
  );

  // Invalid status enum
  await assertFails(
    mealRef.update({
      status: "HACKED_STATUS",
      updatedAt: new Date(),
    })
  );
});
