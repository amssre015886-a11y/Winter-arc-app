package com.example.base

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.google.firebase.FirebaseApp
import com.google.firebase.FirebaseOptions
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.FirebaseFirestoreSettings
import com.google.firebase.firestore.MemoryCacheSettings
import java.net.HttpURLConnection
import java.net.URL
import kotlinx.coroutines.tasks.await
import org.junit.After
import org.junit.Before
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config
import org.robolectric.annotation.LooperMode

@RunWith(RobolectricTestRunner::class)
@Config(manifest = Config.NONE)
@LooperMode(LooperMode.Mode.INSTRUMENTATION_TEST)
abstract class FirestoreEmulatorTestBase {
    protected lateinit var db: FirebaseFirestore
    protected lateinit var auth: FirebaseAuth
    protected val projectId = "demo-no-project"
    protected val databaseId = "ai-studio-android-winterar-7dcd3dcc-f9e3-45b6-9684-c7446487e7eb"

    @Before
    fun baseSetUp() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        if (FirebaseApp.getApps(context).isEmpty()) {
            val options = FirebaseOptions.Builder()
                .setProjectId(projectId)
                .setApplicationId("1:1234567890:android:abcdef")
                .setApiKey("fake-api-key-for-emulator")
                .build()
            FirebaseApp.initializeApp(context, options)
        }
        val app = FirebaseApp.getInstance()

        auth = FirebaseAuth.getInstance(app)
        try {
            auth.useEmulator("127.0.0.1", 9099)
        } catch (_: IllegalStateException) {
            // Already configured on a shared instance
        }

        db = FirebaseFirestore.getInstance(app, databaseId)
        try {
            db.useEmulator("127.0.0.1", 8085)
            db.firestoreSettings = FirebaseFirestoreSettings.Builder()
                .setLocalCacheSettings(MemoryCacheSettings.newBuilder().build())
                .build()
        } catch (_: IllegalStateException) {
            // Already configured on a shared instance
        }

        clearEmulatorData()
    }

    @After
    fun baseTearDown() {
        try {
            auth.signOut()
        } catch (_: Exception) {
        }
        try {
            db.terminate()
            FirebaseApp.clearInstancesForTest()
        } catch (_: Exception) {
        }
    }

    protected suspend fun signInTestUser(email: String, password: String = "password123"): String {
        val result = try {
            auth.createUserWithEmailAndPassword(email, password).await()
        } catch (e: Exception) {
            auth.signInWithEmailAndPassword(email, password).await()
        }
        return requireNotNull(result.user?.uid)
    }

    private fun clearEmulatorData() {
        deleteUrl(
            "http://127.0.0.1:8085/emulator/v1/projects/$projectId/databases/$databaseId/documents"
        )
        deleteUrl(
            "http://127.0.0.1:9099/emulator/v1/projects/$projectId/accounts"
        )
    }

    private fun deleteUrl(urlString: String) {
        val conn = (URL(urlString).openConnection() as HttpURLConnection).apply {
            requestMethod = "DELETE"
            connectTimeout = 5000
            readTimeout = 5000
        }
        try {
            conn.responseCode
        } finally {
            conn.disconnect()
        }
    }
}
