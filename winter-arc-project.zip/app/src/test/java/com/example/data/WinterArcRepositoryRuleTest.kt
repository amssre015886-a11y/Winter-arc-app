package com.example.data

import com.example.base.FirestoreEmulatorTestBase
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.runBlocking
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Assert.fail
import org.junit.Before
import org.junit.Test

class WinterArcRepositoryRuleTest : FirestoreEmulatorTestBase() {
    private lateinit var repository: WinterArcRepository

    @Before
    fun setUp() {
        repository = WinterArcRepository(db = db, auth = auth)
    }

    @Test
    fun saveAndObserveUserProgress_asAuthenticatedOwner_succeeds() = runBlocking {
        val uid = signInTestUser("alice@example.com")

        repository.saveUserProgress(
            userId = uid,
            displayName = "Alice Winter",
            waterIntakeMl = 1500,
            completedSets = listOf("d1_ex0_set0", "d1_ex0_set1"),
            completedCalendarDays = listOf(1, 2),
            isCreate = true
        )

        val progress = repository.observeUserProgress(uid).first { it != null }
        assertNotNull(progress)
        assertEquals(uid, progress?.userId)
        assertEquals("Alice Winter", progress?.displayName)
        assertEquals(1500, progress?.waterIntakeMl)
        assertEquals(listOf("d1_ex0_set0", "d1_ex0_set1"), progress?.completedSets)
        assertEquals(listOf(1, 2), progress?.completedCalendarDays)
    }

    @Test
    fun saveAndObserveMealEntry_asAuthenticatedOwner_succeeds() = runBlocking {
        val uid = signInTestUser("alice@example.com")

        val meal = FirestoreMealEntry(
            id = "meal_1",
            userId = uid,
            name = "Oats & Whey Scoop",
            category = "BREAKFAST",
            calories = 420,
            proteinGrams = 34,
            carbsGrams = 52,
            fatsGrams = 8,
            status = "EATEN",
            isCustom = false
        )
        repository.saveMealEntry(uid, meal, isCreate = true)

        val meals = repository.observeMeals(uid).first { it.isNotEmpty() }
        assertEquals(1, meals.size)
        assertEquals("Oats & Whey Scoop", meals.first().name)
        assertEquals(420, meals.first().calories)
        assertEquals("EATEN", meals.first().status)
    }

    @Test
    fun saveUserProgress_forAnotherUsersDocument_isDeniedByRules() = runBlocking {
        signInTestUser("alice@example.com")

        try {
            repository.saveUserProgress(
                userId = "bob_other_uid",
                displayName = "Hacker",
                waterIntakeMl = 2000,
                completedSets = emptyList(),
                completedCalendarDays = emptyList(),
                isCreate = true
            )
            fail("Expected PERMISSION_DENIED exception when writing to another user's document")
        } catch (e: RuntimeException) {
            assertTrue(
                "Expected PERMISSION_DENIED in error message, got: ${e.message}",
                e.message?.contains("PERMISSION_DENIED") == true
            )
        }
    }

    @Test
    fun saveMealEntry_whenUnauthenticated_isDeniedByRules() = runBlocking {
        auth.signOut()

        val meal = FirestoreMealEntry(
            id = "meal_unauth",
            userId = "some_uid",
            name = "Whey Shake",
            category = "POST_WORKOUT",
            calories = 160,
            proteinGrams = 28,
            carbsGrams = 6,
            fatsGrams = 2,
            status = "EATEN",
            isCustom = true
        )

        try {
            repository.saveMealEntry("some_uid", meal, isCreate = true)
            fail("Expected PERMISSION_DENIED exception when unauthenticated")
        } catch (e: RuntimeException) {
            assertTrue(
                "Expected PERMISSION_DENIED in error message, got: ${e.message}",
                e.message?.contains("PERMISSION_DENIED") == true
            )
        }
    }
}
