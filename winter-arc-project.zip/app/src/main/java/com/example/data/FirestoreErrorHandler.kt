package com.example.data

import android.util.Log
import com.google.firebase.Firebase
import com.google.firebase.auth.auth
import org.json.JSONArray
import org.json.JSONObject

enum class OperationType(val value: String) {
    CREATE("create"),
    UPDATE("update"),
    DELETE("delete"),
    LIST("list"),
    GET("get"),
    WRITE("write")
}

fun handleFirestoreError(
    exception: Throwable,
    operationType: OperationType,
    path: String?
) {
    val currentUser = try {
        Firebase.auth.currentUser
    } catch (e: Exception) {
        null
    }

    val providerArray = JSONArray()
    currentUser?.providerData?.forEach { userInfo ->
        providerArray.put(
            JSONObject().apply {
                put("providerId", userInfo.providerId)
                put("displayName", userInfo.displayName ?: JSONObject.NULL)
                put("email", userInfo.email ?: JSONObject.NULL)
                put("photoUrl", userInfo.photoUrl?.toString() ?: JSONObject.NULL)
            }
        )
    }

    val authInfo = JSONObject().apply {
        put("userId", currentUser?.uid ?: JSONObject.NULL)
        put("email", currentUser?.email ?: JSONObject.NULL)
        put("emailVerified", currentUser?.isEmailVerified ?: JSONObject.NULL)
        put("isAnonymous", currentUser?.isAnonymous ?: JSONObject.NULL)
        put("tenantId", currentUser?.tenantId ?: JSONObject.NULL)
        put("providerInfo", providerArray)
    }

    val errInfo = JSONObject().apply {
        put("error", exception.message ?: exception.toString())
        put("operationType", operationType.value)
        put("path", path ?: JSONObject.NULL)
        put("authInfo", authInfo)
    }

    val jsonString = errInfo.toString()
    Log.e("FirestoreError", "Firestore Error: $jsonString", exception)
    throw RuntimeException(jsonString, exception)
}
