package com.example.data

import android.content.Context
import com.example.R
import com.google.firebase.Firebase
import com.google.firebase.Timestamp
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.auth
import com.google.firebase.firestore.DocumentId
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.IgnoreExtraProperties
import com.google.firebase.firestore.ServerTimestamp
import com.google.firebase.firestore.snapshots
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.tasks.await

@IgnoreExtraProperties
data class FirestoreUserProgress(
    @DocumentId val id: String = "",
    val userId: String = "",
    val displayName: String = "Winter Arc Athlete",
    val waterIntakeMl: Int = 0,
    val completedSets: List<String> = emptyList(),
    val completedCalendarDays: List<Int> = emptyList(),
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
)

@IgnoreExtraProperties
data class FirestoreMealEntry(
    @DocumentId val id: String = "",
    val userId: String = "",
    val name: String = "",
    val category: String = "BREAKFAST",
    val calories: Int = 0,
    val proteinGrams: Int = 0,
    val carbsGrams: Int = 0,
    val fatsGrams: Int = 0,
    val status: String = "PLANNED",
    val isCustom: Boolean = false,
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
)

class WinterArcRepository(
    private val db: FirebaseFirestore,
    private val auth: FirebaseAuth = Firebase.auth
) {
    constructor(context: Context) : this(
        FirebaseFirestore.getInstance(
            context.applicationContext.getString(R.string.firestore_database_id)
        ),
        Firebase.auth
    )

    fun observeUserProgress(userId: String): Flow<FirestoreUserProgress?> {
        val path = "users/$userId"
        return db.collection("users").document(userId)
            .snapshots()
            .map { snapshot ->
                if (snapshot.exists()) {
                    snapshot.toObject(FirestoreUserProgress::class.java)
                } else {
                    null
                }
            }
            .catch { e ->
                handleFirestoreError(e, OperationType.GET, path)
            }
    }

    suspend fun getUserProgress(userId: String): FirestoreUserProgress? {
        val path = "users/$userId"
        return try {
            val snapshot = db.collection("users").document(userId).get().await()
            if (snapshot.exists()) {
                snapshot.toObject(FirestoreUserProgress::class.java)
            } else {
                null
            }
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.GET, path)
            null
        }
    }

    suspend fun saveUserProgress(
        userId: String,
        displayName: String = "Winter Arc Athlete",
        waterIntakeMl: Int,
        completedSets: List<String>,
        completedCalendarDays: List<Int>,
        isCreate: Boolean = false
    ) {
        val path = "users/$userId"
        val cleanName = displayName.trim().ifEmpty { "Winter Arc Athlete" }.take(100)
        val cleanWater = waterIntakeMl.coerceIn(0, 10000)
        val cleanSets = completedSets.take(100)
        val cleanDays = completedCalendarDays.take(35)

        try {
            val docRef = db.collection("users").document(userId)
            if (isCreate) {
                val data = mapOf(
                    "userId" to userId,
                    "displayName" to cleanName,
                    "waterIntakeMl" to cleanWater,
                    "completedSets" to cleanSets,
                    "completedCalendarDays" to cleanDays,
                    "createdAt" to FieldValue.serverTimestamp(),
                    "updatedAt" to FieldValue.serverTimestamp()
                )
                docRef.set(data).await()
            } else {
                val existing = docRef.get().await()
                if (!existing.exists()) {
                    val data = mapOf(
                        "userId" to userId,
                        "displayName" to cleanName,
                        "waterIntakeMl" to cleanWater,
                        "completedSets" to cleanSets,
                        "completedCalendarDays" to cleanDays,
                        "createdAt" to FieldValue.serverTimestamp(),
                        "updatedAt" to FieldValue.serverTimestamp()
                    )
                    docRef.set(data).await()
                } else {
                    val updates = mapOf(
                        "displayName" to cleanName,
                        "waterIntakeMl" to cleanWater,
                        "completedSets" to cleanSets,
                        "completedCalendarDays" to cleanDays,
                        "updatedAt" to FieldValue.serverTimestamp()
                    )
                    docRef.update(updates).await()
                }
            }
        } catch (e: Exception) {
            handleFirestoreError(e, if (isCreate) OperationType.CREATE else OperationType.WRITE, path)
        }
    }

    fun observeMeals(userId: String): Flow<List<FirestoreMealEntry>> {
        val path = "users/$userId/meals"
        return db.collection("users").document(userId).collection("meals")
            .snapshots()
            .map { snapshot ->
                snapshot.documents.mapNotNull { doc ->
                    doc.toObject(FirestoreMealEntry::class.java)
                }
            }
            .catch { e ->
                handleFirestoreError(e, OperationType.LIST, path)
            }
    }

    suspend fun saveMealEntry(userId: String, entry: FirestoreMealEntry, isCreate: Boolean = true) {
        val mealId = entry.id.ifBlank {
            db.collection("users").document(userId).collection("meals").document().id
        }
        val path = "users/$userId/meals/$mealId"
        try {
            val docRef = db.collection("users").document(userId).collection("meals").document(mealId)
            if (isCreate) {
                val data = mapOf(
                    "userId" to userId,
                    "name" to entry.name.trim().ifEmpty { "Meal Item" }.take(120),
                    "category" to entry.category,
                    "calories" to entry.calories.coerceIn(0, 5000),
                    "proteinGrams" to entry.proteinGrams.coerceIn(0, 500),
                    "carbsGrams" to entry.carbsGrams.coerceIn(0, 1000),
                    "fatsGrams" to entry.fatsGrams.coerceIn(0, 500),
                    "status" to entry.status,
                    "isCustom" to entry.isCustom,
                    "createdAt" to FieldValue.serverTimestamp(),
                    "updatedAt" to FieldValue.serverTimestamp()
                )
                docRef.set(data).await()
            } else {
                val updates = mapOf(
                    "name" to entry.name.trim().ifEmpty { "Meal Item" }.take(120),
                    "category" to entry.category,
                    "calories" to entry.calories.coerceIn(0, 5000),
                    "proteinGrams" to entry.proteinGrams.coerceIn(0, 500),
                    "carbsGrams" to entry.carbsGrams.coerceIn(0, 1000),
                    "fatsGrams" to entry.fatsGrams.coerceIn(0, 500),
                    "status" to entry.status,
                    "isCustom" to entry.isCustom,
                    "updatedAt" to FieldValue.serverTimestamp()
                )
                docRef.update(updates).await()
            }
        } catch (e: Exception) {
            handleFirestoreError(e, if (isCreate) OperationType.CREATE else OperationType.UPDATE, path)
        }
    }

    suspend fun deleteMealEntry(userId: String, mealId: String) {
        val path = "users/$userId/meals/$mealId"
        try {
            db.collection("users").document(userId).collection("meals").document(mealId).delete().await()
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.DELETE, path)
        }
    }
}
