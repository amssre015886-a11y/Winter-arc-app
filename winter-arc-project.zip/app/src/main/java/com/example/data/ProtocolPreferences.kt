package com.example.data

import android.content.Context
import android.content.SharedPreferences
import android.util.Log
import com.example.model.DefaultNutritionData
import com.example.model.FoodItem
import com.example.model.MealCategory
import com.example.model.MealItemStatus
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import org.json.JSONArray
import org.json.JSONObject

class ProtocolPreferences(context: Context) {
    private val prefs: SharedPreferences =
        context.getSharedPreferences("winter_arc_protocol_prefs", Context.MODE_PRIVATE)

    private val syncScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private var cloudRepository: WinterArcRepository? = null
    private var activeUserId: String? = null
    private var activeDisplayName: String = "Winter Arc Athlete"
    private var progressListenerJob: Job? = null
    private var mealsListenerJob: Job? = null

    private val _waterIntakeFlow = MutableStateFlow(getWaterIntake())
    val waterIntakeFlow: StateFlow<Int> = _waterIntakeFlow.asStateFlow()

    private val _completedSetsCountFlow = MutableStateFlow(getCompletedSetsCountToday())
    val completedSetsCountFlow: StateFlow<Int> = _completedSetsCountFlow.asStateFlow()

    private val _mealsFlow = MutableStateFlow(loadMeals())
    val mealsFlow: StateFlow<List<FoodItem>> = _mealsFlow.asStateFlow()

    private val _cloudSyncActiveFlow = MutableStateFlow(false)
    val cloudSyncActiveFlow: StateFlow<Boolean> = _cloudSyncActiveFlow.asStateFlow()

    fun bindCloudUser(
        userId: String,
        displayName: String?,
        repository: WinterArcRepository
    ) {
        if (activeUserId == userId && cloudRepository != null) return
        unbindCloudUser()

        activeUserId = userId
        activeDisplayName = displayName?.takeIf { it.isNotBlank() } ?: "Winter Arc Athlete"
        cloudRepository = repository
        _cloudSyncActiveFlow.value = true

        progressListenerJob = syncScope.launch {
            try {
                repository.observeUserProgress(userId).collect { cloudProgress ->
                    if (cloudProgress == null) {
                        // Seed initial cloud document from local state
                        pushProgressToCloud(isCreate = true)
                    } else {
                        applyCloudProgressLocally(cloudProgress)
                    }
                }
            } catch (e: Exception) {
                Log.w("ProtocolPreferences", "Progress sync listener error: ${e.message}")
            }
        }

        mealsListenerJob = syncScope.launch {
            try {
                repository.observeMeals(userId).collect { cloudMeals ->
                    if (cloudMeals.isEmpty()) {
                        // Seed default meals to cloud
                        val currentMeals = _mealsFlow.value
                        currentMeals.forEach { item ->
                            pushMealToCloud(item, isCreate = true)
                        }
                    } else {
                        val mapped = cloudMeals.map { entry ->
                            val category = runCatching { MealCategory.valueOf(entry.category) }
                                .getOrDefault(MealCategory.BREAKFAST)
                            val status = runCatching { MealItemStatus.valueOf(entry.status) }
                                .getOrDefault(MealItemStatus.PLANNED)
                            FoodItem(
                                id = entry.id,
                                name = entry.name,
                                category = category,
                                calories = entry.calories,
                                proteinGrams = entry.proteinGrams,
                                carbsGrams = entry.carbsGrams,
                                fatsGrams = entry.fatsGrams,
                                status = status,
                                isCustom = entry.isCustom
                            )
                        }
                        saveMealsLocallyOnly(mapped)
                    }
                }
            } catch (e: Exception) {
                Log.w("ProtocolPreferences", "Meals sync listener error: ${e.message}")
            }
        }
    }

    fun unbindCloudUser() {
        progressListenerJob?.cancel()
        mealsListenerJob?.cancel()
        progressListenerJob = null
        mealsListenerJob = null
        activeUserId = null
        cloudRepository = null
        _cloudSyncActiveFlow.value = false
    }

    private fun applyCloudProgressLocally(cloudProgress: FirestoreUserProgress) {
        val editor = prefs.edit()
        editor.putInt("water_intake_today", cloudProgress.waterIntakeMl)

        // Clear old set_ keys and apply cloud completedSets
        for (key in prefs.all.keys) {
            if (key.startsWith("set_") || key.startsWith("calendar_day_")) {
                editor.remove(key)
            }
        }
        cloudProgress.completedSets.forEach { setKey ->
            editor.putBoolean(setKey, true)
        }
        for (day in 1..30) {
            editor.putBoolean(
                "calendar_day_${day}_done",
                cloudProgress.completedCalendarDays.contains(day)
            )
        }
        editor.apply()

        _waterIntakeFlow.value = cloudProgress.waterIntakeMl
        _completedSetsCountFlow.value = cloudProgress.completedSets.size
    }

    private fun getAllCompletedSetKeys(): List<String> {
        return prefs.all.entries
            .filter { it.key.startsWith("set_") && it.value == true }
            .map { it.key }
            .sorted()
    }

    private fun getAllCompletedCalendarDays(): List<Int> {
        val days = mutableListOf<Int>()
        for (day in 1..30) {
            if (isCalendarDayCompleted(day)) {
                days.add(day)
            }
        }
        return days
    }

    private fun pushProgressToCloud(isCreate: Boolean = false) {
        val uid = activeUserId ?: return
        val repo = cloudRepository ?: return
        val water = getWaterIntake()
        val sets = getAllCompletedSetKeys()
        val days = getAllCompletedCalendarDays()
        val displayName = activeDisplayName

        syncScope.launch {
            try {
                repo.saveUserProgress(
                    userId = uid,
                    displayName = displayName,
                    waterIntakeMl = water,
                    completedSets = sets,
                    completedCalendarDays = days,
                    isCreate = isCreate
                )
            } catch (e: Exception) {
                Log.w("ProtocolPreferences", "Failed to sync progress to Firestore: ${e.message}")
            }
        }
    }

    private fun pushMealToCloud(item: FoodItem, isCreate: Boolean) {
        val uid = activeUserId ?: return
        val repo = cloudRepository ?: return
        val sanitizedId = item.id.replace(Regex("[^a-zA-Z0-9_\\-]"), "_").take(128)
        val entry = FirestoreMealEntry(
            id = sanitizedId,
            userId = uid,
            name = item.name,
            category = item.category.name,
            calories = item.calories,
            proteinGrams = item.proteinGrams,
            carbsGrams = item.carbsGrams,
            fatsGrams = item.fatsGrams,
            status = item.status.name,
            isCustom = item.isCustom
        )
        syncScope.launch {
            try {
                repo.saveMealEntry(uid, entry, isCreate = isCreate)
            } catch (e: Exception) {
                Log.w("ProtocolPreferences", "Failed to sync meal to Firestore: ${e.message}")
            }
        }
    }

    fun isSetCompleted(exerciseId: String, setIndex: Int): Boolean {
        return prefs.getBoolean("set_${exerciseId}_${setIndex}", false)
    }

    fun toggleSetCompleted(exerciseId: String, setIndex: Int): Boolean {
        val current = isSetCompleted(exerciseId, setIndex)
        val newState = !current
        prefs.edit().putBoolean("set_${exerciseId}_${setIndex}", newState).apply()
        _completedSetsCountFlow.value = getCompletedSetsCountToday()
        pushProgressToCloud()
        return newState
    }

    fun resetSetsForExercise(exerciseId: String, totalSets: Int) {
        val editor = prefs.edit()
        for (i in 0 until totalSets) {
            editor.remove("set_${exerciseId}_${i}")
        }
        editor.apply()
        _completedSetsCountFlow.value = getCompletedSetsCountToday()
        pushProgressToCloud()
    }

    fun resetAllSetsToday() {
        val allKeys = prefs.all.keys
        val editor = prefs.edit()
        for (key in allKeys) {
            if (key.startsWith("set_")) {
                editor.remove(key)
            }
        }
        editor.apply()
        _completedSetsCountFlow.value = 0
        pushProgressToCloud()
    }

    private fun getCompletedSetsCountToday(): Int {
        var count = 0
        for ((key, value) in prefs.all) {
            if (key.startsWith("set_") && value == true) {
                count++
            }
        }
        return count
    }

    // WATER TRACKER
    fun getWaterIntake(): Int {
        return prefs.getInt("water_intake_today", 1250)
    }

    fun addWater(amountMl: Int): Int {
        val current = getWaterIntake()
        val updated = (current + amountMl).coerceIn(0, 8000)
        prefs.edit().putInt("water_intake_today", updated).apply()
        _waterIntakeFlow.value = updated
        pushProgressToCloud()
        return updated
    }

    fun undoWater(amountMl: Int = 250): Int {
        val current = getWaterIntake()
        val updated = (current - amountMl).coerceAtLeast(0)
        prefs.edit().putInt("water_intake_today", updated).apply()
        _waterIntakeFlow.value = updated
        pushProgressToCloud()
        return updated
    }

    fun resetWater(): Int {
        prefs.edit().putInt("water_intake_today", 0).apply()
        _waterIntakeFlow.value = 0
        pushProgressToCloud()
        return 0
    }

    fun getWaterTarget(): Int {
        return prefs.getInt("water_target_ml", 3500)
    }

    // 30-DAY CALENDAR TRACKING
    fun isCalendarDayCompleted(dayNumber: Int): Boolean {
        return prefs.getBoolean("calendar_day_${dayNumber}_done", dayNumber < 3)
    }

    fun toggleCalendarDay(dayNumber: Int): Boolean {
        val current = isCalendarDayCompleted(dayNumber)
        val newState = !current
        prefs.edit().putBoolean("calendar_day_${dayNumber}_done", newState).apply()
        pushProgressToCloud()
        return newState
    }

    // CALORIE & MEAL TRACKER PERSISTENCE
    private fun loadMeals(): List<FoodItem> {
        val rawJson = prefs.getString("nutrition_meals_json_v1", null)
            ?: return DefaultNutritionData.defaultMeals
        return try {
            val array = JSONArray(rawJson)
            val list = mutableListOf<FoodItem>()
            for (i in 0 until array.length()) {
                val obj = array.getJSONObject(i)
                val categoryName = obj.optString("category", MealCategory.BREAKFAST.name)
                val category = runCatching { MealCategory.valueOf(categoryName) }
                    .getOrDefault(MealCategory.BREAKFAST)
                val statusName = obj.optString("status", MealItemStatus.PLANNED.name)
                val status = runCatching { MealItemStatus.valueOf(statusName) }
                    .getOrDefault(MealItemStatus.PLANNED)
                list.add(
                    FoodItem(
                        id = obj.getString("id"),
                        name = obj.getString("name"),
                        category = category,
                        calories = obj.optInt("calories", 0),
                        proteinGrams = obj.optInt("proteinGrams", 0),
                        carbsGrams = obj.optInt("carbsGrams", 0),
                        fatsGrams = obj.optInt("fatsGrams", 0),
                        status = status,
                        isCustom = obj.optBoolean("isCustom", false)
                    )
                )
            }
            if (list.isEmpty()) DefaultNutritionData.defaultMeals else list
        } catch (e: Exception) {
            DefaultNutritionData.defaultMeals
        }
    }

    private fun saveMealsLocallyOnly(meals: List<FoodItem>) {
        val array = JSONArray()
        meals.forEach { item ->
            val obj = JSONObject().apply {
                put("id", item.id)
                put("name", item.name)
                put("category", item.category.name)
                put("calories", item.calories)
                put("proteinGrams", item.proteinGrams)
                put("carbsGrams", item.carbsGrams)
                put("fatsGrams", item.fatsGrams)
                put("status", item.status.name)
                put("isCustom", item.isCustom)
            }
            array.put(obj)
        }
        prefs.edit().putString("nutrition_meals_json_v1", array.toString()).apply()
        _mealsFlow.value = meals
    }

    fun updateMealItemStatus(itemId: String, newStatus: MealItemStatus) {
        var changedItem: FoodItem? = null
        val updated = _mealsFlow.value.map { item ->
            if (item.id == itemId) {
                val copy = item.copy(status = newStatus)
                changedItem = copy
                copy
            } else {
                item
            }
        }
        saveMealsLocallyOnly(updated)
        changedItem?.let { pushMealToCloud(it, isCreate = false) }
    }

    fun cycleMealItemStatus(itemId: String) {
        var changedItem: FoodItem? = null
        val updated = _mealsFlow.value.map { item ->
            if (item.id == itemId) {
                val nextStatus = when (item.status) {
                    MealItemStatus.PLANNED -> MealItemStatus.EATEN
                    MealItemStatus.EATEN -> MealItemStatus.SKIPPED
                    MealItemStatus.SKIPPED -> MealItemStatus.EATEN
                }
                val copy = item.copy(status = nextStatus)
                changedItem = copy
                copy
            } else {
                item
            }
        }
        saveMealsLocallyOnly(updated)
        changedItem?.let { pushMealToCloud(it, isCreate = false) }
    }

    fun addFoodItem(
        name: String,
        category: MealCategory,
        calories: Int,
        protein: Int,
        carbs: Int,
        fats: Int,
        markEatenImmediately: Boolean = true
    ) {
        val newItem = FoodItem(
            id = "custom_${System.currentTimeMillis()}",
            name = name.trim().ifEmpty { "Custom Meal" },
            category = category,
            calories = calories.coerceIn(0, 5000),
            proteinGrams = protein.coerceIn(0, 500),
            carbsGrams = carbs.coerceIn(0, 1000),
            fatsGrams = fats.coerceIn(0, 500),
            status = if (markEatenImmediately) MealItemStatus.EATEN else MealItemStatus.PLANNED,
            isCustom = true
        )
        saveMealsLocallyOnly(_mealsFlow.value + newItem)
        pushMealToCloud(newItem, isCreate = true)
    }

    fun deleteFoodItem(itemId: String) {
        saveMealsLocallyOnly(_mealsFlow.value.filterNot { it.id == itemId })
        val uid = activeUserId ?: return
        val repo = cloudRepository ?: return
        syncScope.launch {
            try {
                repo.deleteMealEntry(uid, itemId)
            } catch (e: Exception) {
                Log.w("ProtocolPreferences", "Failed to delete meal in Firestore: ${e.message}")
            }
        }
    }

    fun resetMealsToDefault() {
        prefs.edit().remove("nutrition_meals_json_v1").apply()
        val defaults = DefaultNutritionData.defaultMeals
        _mealsFlow.value = defaults
        defaults.forEach { item ->
            pushMealToCloud(item, isCreate = true)
        }
    }
}
