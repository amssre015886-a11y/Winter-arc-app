package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.material3.Scaffold
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.ai.WinterArcAiViewModel
import com.example.data.ProtocolPreferences
import com.example.data.WinterArcRepository
import com.example.model.Exercise
import com.example.model.WorkoutRepository
import com.example.ui.auth.AuthScreen
import com.example.ui.auth.signOutWinterArcUser
import com.example.ui.components.AmbientBackground
import com.example.ui.components.AppTab
import com.example.ui.components.BottomTabBar
import com.example.ui.components.DynamicIslandBar
import com.example.ui.components.VideoPlayerDialog
import com.example.ui.tabs.CalendarTab
import com.example.ui.tabs.CalorieTrackerTab
import com.example.ui.tabs.TimerConsoleTab
import com.example.ui.tabs.TodayGoalTab
import com.example.ui.tabs.WaterTrackerTab
import com.example.ui.theme.WinterArcTheme
import com.example.util.configureAppCheck
import com.google.firebase.Firebase
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.auth
import java.util.Calendar
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // STEP 1: Configure Firebase App Check with launch intent before any UI or Firebase operations
        configureAppCheck(this, intent)

        enableEdgeToEdge()

        val protocolPrefs = ProtocolPreferences(applicationContext)
        val cloudRepository = WinterArcRepository(applicationContext)

        setContent {
            WinterArcTheme {
                val context = LocalContext.current
                val coroutineScope = rememberCoroutineScope()
                var currentUser by remember { mutableStateOf(Firebase.auth.currentUser) }

                DisposableEffect(Unit) {
                    val listener = FirebaseAuth.AuthStateListener { auth ->
                        currentUser = auth.currentUser
                    }
                    Firebase.auth.addAuthStateListener(listener)
                    onDispose {
                        Firebase.auth.removeAuthStateListener(listener)
                    }
                }

                LaunchedEffect(currentUser?.uid) {
                    val user = currentUser
                    if (user != null) {
                        protocolPrefs.bindCloudUser(
                            userId = user.uid,
                            displayName = user.displayName ?: user.email,
                            repository = cloudRepository
                        )
                    } else {
                        protocolPrefs.unbindCloudUser()
                    }
                }

                if (currentUser == null) {
                    AuthScreen(
                        onSignedIn = {
                            currentUser = Firebase.auth.currentUser
                        }
                    )
                } else {
                    WinterArcApp(
                        protocolPrefs = protocolPrefs,
                        userName = currentUser?.displayName ?: currentUser?.email ?: "Athlete",
                        onSignOut = {
                            coroutineScope.launch {
                                protocolPrefs.unbindCloudUser()
                                signOutWinterArcUser(context)
                                currentUser = null
                            }
                        }
                    )
                }
            }
        }
    }
}

@Composable
fun WinterArcApp(
    protocolPrefs: ProtocolPreferences,
    userName: String? = null,
    onSignOut: (() -> Unit)? = null,
    aiViewModel: WinterArcAiViewModel = viewModel()
) {
    var currentTab by remember { mutableStateOf(AppTab.TODAY) }
    var activeVideoExercise by remember { mutableStateOf<Exercise?>(null) }

    // Calculate current day of week (Calendar: SUNDAY = 1, MONDAY = 2, ...)
    val currentDayIndex = remember {
        val cal = Calendar.getInstance()
        cal.get(Calendar.DAY_OF_WEEK) - 1 // 0 = Sunday, 1 = Monday, ... 6 = Saturday
    }
    val todayProtocol = remember(currentDayIndex) {
        WorkoutRepository.getProtocolForDayOfWeek(currentDayIndex)
    }

    // Android back button handling: if in another tab, return to Today's Goal tab
    BackHandler(enabled = currentTab != AppTab.TODAY) {
        currentTab = AppTab.TODAY
    }

    Box(modifier = Modifier.fillMaxSize()) {
        // 1. Animated Ambient Background Canvas (with glowing auroras & drifting particles)
        AmbientBackground(modifier = Modifier.fillMaxSize())

        // 2. Main Content Layout
        Scaffold(
            containerColor = Color.Transparent,
            topBar = {
                DynamicIslandBar(
                    dayTag = todayProtocol.tag,
                    dayNumber = 1,
                    userName = userName,
                    onSignOut = onSignOut
                )
            },
            bottomBar = {
                BottomTabBar(
                    selectedTab = currentTab,
                    onTabSelected = { currentTab = it }
                )
            }
        ) { paddingValues ->
            Box(
                modifier = Modifier
                    .fillMaxSize()
            ) {
                // Smooth transition between tabs
                AnimatedContent(
                    targetState = currentTab,
                    transitionSpec = {
                        fadeIn(animationSpec = tween(220)) togetherWith
                                fadeOut(animationSpec = tween(180))
                    },
                    label = "tab_transition",
                    modifier = Modifier.fillMaxSize()
                ) { tab ->
                    Column(
                        modifier = Modifier
                            .fillMaxSize(),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        // Top spacing to clear dynamic island
                        Box(modifier = Modifier.height(paddingValues.calculateTopPadding()))

                        when (tab) {
                            AppTab.TODAY -> {
                                TodayGoalTab(
                                    protocolPrefs = protocolPrefs,
                                    onWatchVideo = { exercise ->
                                        activeVideoExercise = exercise
                                    },
                                    onOpenCaloriesTab = {
                                        currentTab = AppTab.CALORIES
                                    }
                                )
                            }
                            AppTab.CALORIES -> {
                                CalorieTrackerTab(
                                    protocolPrefs = protocolPrefs,
                                    aiViewModel = aiViewModel,
                                    currentWorkoutTitle = todayProtocol.title
                                )
                            }
                            AppTab.CALENDAR -> {
                                CalendarTab(protocolPrefs = protocolPrefs)
                            }
                            AppTab.WATER -> {
                                WaterTrackerTab(protocolPrefs = protocolPrefs)
                            }
                            AppTab.TIMER -> {
                                TimerConsoleTab(protocolPrefs = protocolPrefs)
                            }
                        }
                    }
                }
            }
        }

        // 3. MuscleWiki Motion Visualizer Dialog Modal
        activeVideoExercise?.let { exercise ->
            VideoPlayerDialog(
                exercise = exercise,
                onDismiss = { activeVideoExercise = null }
            )
        }
    }
}
