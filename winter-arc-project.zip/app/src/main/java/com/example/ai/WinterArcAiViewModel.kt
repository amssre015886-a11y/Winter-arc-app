package com.example.ai

import android.util.Log
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.model.FoodItem
import com.example.model.MealItemStatus
import com.google.firebase.Firebase
import com.google.firebase.ai.ai
import com.google.firebase.ai.type.Schema
import com.google.firebase.ai.type.generationConfig
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.TimeoutCancellationException
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withTimeout
import org.json.JSONObject

private const val TAG = "WinterArcAiVM"

data class AiAnalyzedFood(
    val foodName: String,
    val calories: Int,
    val proteinGrams: Int,
    val carbsGrams: Int,
    val fatsGrams: Int,
    val coachVerdict: String
)

sealed interface FoodAnalysisUiState {
    data object Idle : FoodAnalysisUiState
    data object Loading : FoodAnalysisUiState
    data class Success(val analyzedFood: AiAnalyzedFood) : FoodAnalysisUiState
    data class Error(val message: String) : FoodAnalysisUiState
}

sealed interface CoachStreamUiState {
    data object Idle : CoachStreamUiState
    data object Loading : CoachStreamUiState
    data class Streaming(val text: String) : CoachStreamUiState
    data class Success(val text: String) : CoachStreamUiState
    data class Error(val message: String) : CoachStreamUiState
}

class WinterArcAiViewModel : ViewModel() {

    private val foodJsonSchema = Schema.obj(
        properties = mapOf(
            "foodName" to Schema.string(description = "Clean formatted name of the food or meal item with portion"),
            "calories" to Schema.integer(description = "Estimated total calories in kcal"),
            "proteinGrams" to Schema.integer(description = "Estimated protein in grams"),
            "carbsGrams" to Schema.integer(description = "Estimated carbohydrates in grams"),
            "fatsGrams" to Schema.integer(description = "Estimated fats in grams"),
            "coachVerdict" to Schema.string(description = "Short 1-sentence high-impact Winter Arc nutrition tip for this food")
        )
    )

    private val structuredFoodModel by lazy {
        Firebase.ai.generativeModel(
            modelName = "gemini-3.8-flash",
            generationConfig = generationConfig {
                responseMimeType = "application/json"
                responseSchema = foodJsonSchema
            }
        )
    }

    private val streamingCoachModel by lazy {
        Firebase.ai.generativeModel(
            modelName = "gemini-3.8-flash"
        )
    }

    private val _foodAnalysisState = MutableStateFlow<FoodAnalysisUiState>(FoodAnalysisUiState.Idle)
    val foodAnalysisState: StateFlow<FoodAnalysisUiState> = _foodAnalysisState.asStateFlow()

    private val _coachStreamState = MutableStateFlow<CoachStreamUiState>(CoachStreamUiState.Idle)
    val coachStreamState: StateFlow<CoachStreamUiState> = _coachStreamState.asStateFlow()

    fun resetFoodAnalysis() {
        _foodAnalysisState.value = FoodAnalysisUiState.Idle
    }

    fun resetCoachStream() {
        _coachStreamState.value = CoachStreamUiState.Idle
    }

    /**
     * Uses Gemini 3.8 Flash with structured JSON output to estimate calories & macros
     * for any food description (including Indian home/hostel meals or skipped meal replacements).
     */
    fun analyzeFoodDescription(description: String) {
        if (description.isBlank()) {
            _foodAnalysisState.value = FoodAnalysisUiState.Error("Please enter a food or meal description first.")
            return
        }

        viewModelScope.launch {
            _foodAnalysisState.value = FoodAnalysisUiState.Loading
            try {
                val prompt = """
                    Analyze the following food/meal item for a fitness & muscle building tracker ("Winter Arc Protocol"):
                    Input: "$description"
                    Provide realistic, accurate nutrition estimates (calories, proteinGrams, carbsGrams, fatsGrams) and a brief coachVerdict.
                """.trimIndent()

                val response = withTimeout(60_000L) {
                    structuredFoodModel.generateContent(prompt)
                }

                val jsonString = response.text ?: throw IllegalStateException("Model returned empty text.")
                val json = JSONObject(jsonString)

                val result = AiAnalyzedFood(
                    foodName = json.optString("foodName", description.trim()),
                    calories = json.optInt("calories", 250).coerceAtLeast(0),
                    proteinGrams = json.optInt("proteinGrams", 15).coerceAtLeast(0),
                    carbsGrams = json.optInt("carbsGrams", 25).coerceAtLeast(0),
                    fatsGrams = json.optInt("fatsGrams", 8).coerceAtLeast(0),
                    coachVerdict = json.optString("coachVerdict", "Solid fuel for muscle recovery.")
                )
                _foodAnalysisState.value = FoodAnalysisUiState.Success(result)
            } catch (e: TimeoutCancellationException) {
                Log.e(TAG, "Food macro analysis timed out", e)
                _foodAnalysisState.value = FoodAnalysisUiState.Error(
                    "AI analysis timed out after 60 seconds. Please try again."
                )
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                Log.e(TAG, "Firebase AI food analysis failed", e)
                _foodAnalysisState.value = FoodAnalysisUiState.Error(
                    e.localizedMessage ?: "Failed to analyze food item."
                )
            }
        }
    }

    /**
     * Streams a real-time personalized Winter Arc optimization plan using Gemini 3.8 Flash,
     * factoring in skipped meal items, eaten calories/protein, workout day, and hydration.
     */
    fun streamProtocolOptimization(
        workoutTitle: String,
        completedSets: Int,
        waterMl: Int,
        meals: List<FoodItem>,
        customQuestion: String = ""
    ) {
        viewModelScope.launch {
            _coachStreamState.value = CoachStreamUiState.Loading
            val accumulatedText = StringBuilder()

            val eatenItems = meals.filter { it.status == MealItemStatus.EATEN }
            val skippedItems = meals.filter { it.status == MealItemStatus.SKIPPED }
            val totalKcal = eatenItems.sumOf { it.calories }
            val totalProtein = eatenItems.sumOf { it.proteinGrams }

            val skippedSummary = if (skippedItems.isEmpty()) {
                "None skipped today"
            } else {
                skippedItems.joinToString(", ") { "${it.name} (${it.calories} kcal, ${it.proteinGrams}g P)" }
            }

            val eatenSummary = if (eatenItems.isEmpty()) {
                "Nothing logged as eaten yet"
            } else {
                eatenItems.joinToString(", ") { "${it.name} (${it.calories} kcal, ${it.proteinGrams}g P)" }
            }

            val prompt = buildString {
                appendLine("You are the elite 'Winter Arc // iOS 26 Protocol' AI Performance & Nutrition Coach.")
                appendLine("Current Protocol Status:")
                appendLine("- Workout Session: $workoutTitle ($completedSets sets completed so far)")
                appendLine("- Hydration: ${waterMl}ml / 3500ml")
                appendLine("- Consumed Today: $totalKcal / 2450 kcal | ${totalProtein}g / 155g Protein")
                appendLine("- Eaten Items: $eatenSummary")
                appendLine("- Skipped Meal Items: $skippedSummary")
                if (customQuestion.isNotBlank()) {
                    appendLine("- User Question / Context: $customQuestion")
                }
                appendLine()
                appendLine("Provide a concise, high-impact optimization plan in 3 bullet points (mix of crisp English & motivating Hinglish):")
                appendLine("1. Skipped Meal Recovery / Replacement (specific high-protein Indian/gym foods to add right now to make up for skipped items or remaining macros).")
                appendLine("2. Workout & Intra/Post-Session Fueling adjustment for $workoutTitle.")
                appendLine("3. Night Recovery & Hydration target before sleep.")
            }

            try {
                withTimeout(60_000L) {
                    streamingCoachModel.generateContentStream(prompt).collect { chunk ->
                        val chunkText = chunk.text.orEmpty()
                        accumulatedText.append(chunkText)
                        _coachStreamState.value = CoachStreamUiState.Streaming(accumulatedText.toString())
                    }
                }
                if (accumulatedText.isNotBlank()) {
                    _coachStreamState.value = CoachStreamUiState.Success(accumulatedText.toString())
                } else {
                    _coachStreamState.value = CoachStreamUiState.Error("Model returned an empty response.")
                }
            } catch (e: TimeoutCancellationException) {
                Log.e(TAG, "Coach streaming timed out", e)
                _coachStreamState.value = CoachStreamUiState.Error(
                    "Optimization stream timed out after 60 seconds. Please try again."
                )
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                Log.e(TAG, "Coach streaming generation failed", e)
                _coachStreamState.value = CoachStreamUiState.Error(
                    e.localizedMessage ?: "AI optimization failed."
                )
            }
        }
    }
}
