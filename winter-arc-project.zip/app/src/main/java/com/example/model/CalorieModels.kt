package com.example.model

enum class MealCategory(val displayName: String, val timeHint: String) {
    BREAKFAST("Breakfast", "08:00 AM"),
    LUNCH("Lunch", "01:30 PM"),
    PRE_WORKOUT("Pre-Workout", "05:00 PM"),
    POST_WORKOUT("Post-Workout", "07:00 PM"),
    DINNER("Dinner", "09:00 PM")
}

enum class MealItemStatus {
    EATEN,
    SKIPPED,
    PLANNED
}

data class FoodItem(
    val id: String,
    val name: String,
    val category: MealCategory,
    val calories: Int,
    val proteinGrams: Int,
    val carbsGrams: Int,
    val fatsGrams: Int,
    val status: MealItemStatus = MealItemStatus.PLANNED,
    val isCustom: Boolean = false
)

data class QuickFoodPreset(
    val name: String,
    val calories: Int,
    val protein: Int,
    val carbs: Int,
    val fats: Int
)

object DefaultNutritionData {
    const val DEFAULT_CALORIE_TARGET = 2450
    const val DEFAULT_PROTEIN_TARGET = 155
    const val DEFAULT_CARBS_TARGET = 260
    const val DEFAULT_FATS_TARGET = 70

    val defaultMeals: List<FoodItem> = listOf(
        // Breakfast
        FoodItem(
            id = "meal_bf_1",
            name = "Rolled Oats (60g) + Milk + 1 Banana",
            category = MealCategory.BREAKFAST,
            calories = 390,
            proteinGrams = 15,
            carbsGrams = 64,
            fatsGrams = 8,
            status = MealItemStatus.EATEN
        ),
        FoodItem(
            id = "meal_bf_2",
            name = "4 Whole Boiled Eggs (Desi Style)",
            category = MealCategory.BREAKFAST,
            calories = 280,
            proteinGrams = 24,
            carbsGrams = 2,
            fatsGrams = 20,
            status = MealItemStatus.EATEN
        ),
        // Lunch
        FoodItem(
            id = "meal_ln_1",
            name = "2 Multigrain Roti + 100g Paneer Bhurji",
            category = MealCategory.LUNCH,
            calories = 520,
            proteinGrams = 26,
            carbsGrams = 48,
            fatsGrams = 24,
            status = MealItemStatus.PLANNED
        ),
        FoodItem(
            id = "meal_ln_2",
            name = "1 Bowl Thick Toor Dal + Green Salad",
            category = MealCategory.LUNCH,
            calories = 190,
            proteinGrams = 10,
            carbsGrams = 28,
            fatsGrams = 4,
            status = MealItemStatus.PLANNED
        ),
        // Pre-Workout
        FoodItem(
            id = "meal_pre_1",
            name = "Black Coffee + 2 Bananas + 1 Spoon Peanut Butter",
            category = MealCategory.PRE_WORKOUT,
            calories = 295,
            proteinGrams = 6,
            carbsGrams = 52,
            fatsGrams = 8,
            status = MealItemStatus.PLANNED
        ),
        // Post-Workout
        FoodItem(
            id = "meal_post_1",
            name = "1 Scoop Whey Isolate + 5g Creatine",
            category = MealCategory.POST_WORKOUT,
            calories = 130,
            proteinGrams = 26,
            carbsGrams = 3,
            fatsGrams = 1,
            status = MealItemStatus.PLANNED
        ),
        // Dinner
        FoodItem(
            id = "meal_dn_1",
            name = "150g Grilled Chicken / 60g Soya Chunks + Rice",
            category = MealCategory.DINNER,
            calories = 480,
            proteinGrams = 42,
            carbsGrams = 55,
            fatsGrams = 9,
            status = MealItemStatus.PLANNED
        ),
        FoodItem(
            id = "meal_dn_2",
            name = "1 Bowl Dahi (Curd) / Warm Turmeric Milk",
            category = MealCategory.DINNER,
            calories = 135,
            proteinGrams = 8,
            carbsGrams = 12,
            fatsGrams = 6,
            status = MealItemStatus.PLANNED
        )
    )

    val quickPresets: List<QuickFoodPreset> = listOf(
        QuickFoodPreset("100g Raw Paneer", 265, 18, 3, 20),
        QuickFoodPreset("2 Boiled Eggs", 140, 12, 1, 10),
        QuickFoodPreset("1 Scoop Whey Protein", 125, 25, 3, 1),
        QuickFoodPreset("50g Soya Chunks", 172, 26, 16, 1),
        QuickFoodPreset("2 Wheat Roti", 200, 6, 40, 2),
        QuickFoodPreset("1 Bowl Dal Tadka", 160, 9, 24, 4),
        QuickFoodPreset("150g Chicken Breast", 248, 46, 0, 5),
        QuickFoodPreset("1 Tbsp Peanut Butter", 95, 4, 3, 8),
        QuickFoodPreset("2 Medium Bananas", 210, 2, 54, 1),
        QuickFoodPreset("1 Bowl Curd (Dahi)", 110, 6, 8, 6)
    )
}
