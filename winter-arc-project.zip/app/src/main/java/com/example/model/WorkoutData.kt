package com.example.model

data class Exercise(
    val id: String,
    val name: String,
    val targetMuscle: String,
    val sets: Int,
    val reps: String,
    val note: String,
    val videoUrl: String,
    val wikiUrl: String
)

data class WarmupItem(
    val title: String,
    val detail: String
)

data class DayProtocol(
    val dayOfWeekIndex: Int, // 0 = Sunday, 1 = Monday, ... 6 = Saturday
    val dayName: String,
    val title: String,
    val subtitle: String,
    val targetDuration: String,
    val energyLevel: String,
    val tag: String,
    val warmups: List<WarmupItem>,
    val exercises: List<Exercise>
)

object WorkoutRepository {
    val protocols = listOf(
        // DAY 0: SUNDAY
        DayProtocol(
            dayOfWeekIndex = 0,
            dayName = "Sunday",
            title = "Sunday Push Protocol",
            subtitle = "Chest, Shoulders & Triceps foundation. Focus on strict form and full lockout.",
            targetDuration = "45m",
            energyLevel = "100%",
            tag = "PUSH DAY",
            warmups = listOf(
                WarmupItem("Arm Circles & Shoulder Rotations", "30s clockwise / 30s anti-clockwise"),
                WarmupItem("Torso Twists", "Bina weight - 1 min waist mobility"),
                WarmupItem("Push-ups", "Light warm-up pace - 10 to 12 reps"),
                WarmupItem("Band / Light Chest Flys", "Chest activation - 15 slow reps")
            ),
            exercises = listOf(
                Exercise(
                    id = "sun_ex_1",
                    name = "Incline Dumbbell Press",
                    targetMuscle = "Upper Chest & Anterior Delt",
                    sets = 3,
                    reps = "8 - 12 Reps",
                    note = "Bench 30 degree incline par rakhein. Elbows ko 45-degree angle par rakhein, kandhe pe stress na aaye.",
                    videoUrl = "https://media.musclewiki.com/media/uploads/videos/branded/male-dumbbell-incline-chest-press-front.mp4",
                    wikiUrl = "https://musclewiki.com/dumbbells/male/chest/dumbbell-incline-chest-press"
                ),
                Exercise(
                    id = "sun_ex_2",
                    name = "Flat Barbell Bench Press",
                    targetMuscle = "Mid Chest & Triceps",
                    sets = 3,
                    reps = "8 - 10 Reps",
                    note = "Shoulder blades pinch karke chest bahar rakhein. Barbell ko nipples ke paas layein aur control se push karein.",
                    videoUrl = "https://media.musclewiki.com/media/uploads/videos/branded/male-barbell-bench-press-front.mp4",
                    wikiUrl = "https://musclewiki.com/barbell/male/chest/barbell-bench-press"
                ),
                Exercise(
                    id = "sun_ex_3",
                    name = "Dumbbell Overhead Shoulder Press",
                    targetMuscle = "Front & Lateral Delts",
                    sets = 3,
                    reps = "10 - 12 Reps",
                    note = "Core tight rakhein. Pure range of motion ke saath upar push karein bina lower back ko arch kiye.",
                    videoUrl = "https://media.musclewiki.com/media/uploads/videos/branded/male-dumbbell-overhead-press-front.mp4",
                    wikiUrl = "https://musclewiki.com/dumbbells/male/shoulders/dumbbell-overhead-press"
                ),
                Exercise(
                    id = "sun_ex_4",
                    name = "Dumbbell Lateral Raises",
                    targetMuscle = "Side Deltoids (3D Look)",
                    sets = 3,
                    reps = "12 - 15 Reps",
                    note = "Halke weight se strict form. Thoda aage jhukein aur elbows se lead karein, swing na karein.",
                    videoUrl = "https://media.musclewiki.com/media/uploads/videos/branded/male-dumbbell-lateral-raise-front.mp4",
                    wikiUrl = "https://musclewiki.com/dumbbells/male/shoulders/dumbbell-lateral-raise"
                ),
                Exercise(
                    id = "sun_ex_5",
                    name = "Triceps Cable Pushdown",
                    targetMuscle = "Triceps Lateral & Long Head",
                    sets = 3,
                    reps = "12 - 15 Reps",
                    note = "Elbows ko body ke saath lock rakhein. Bottom par poora spread karein aur 1 sec hold karein.",
                    videoUrl = "https://media.musclewiki.com/media/uploads/videos/branded/male-cable-pushdown-front.mp4",
                    wikiUrl = "https://musclewiki.com/cables/male/triceps/cable-pushdown"
                )
            )
        ),

        // DAY 1: MONDAY
        DayProtocol(
            dayOfWeekIndex = 1,
            dayName = "Monday",
            title = "Monday Pull Protocol",
            subtitle = "Back Width, Thickness & Bicep Peak. V-Taper construction.",
            targetDuration = "50m",
            energyLevel = "95%",
            tag = "PULL DAY",
            warmups = listOf(
                WarmupItem("Dead Hangs", "30-45s body decompression"),
                WarmupItem("Cat-Cow Stretches", "Spine mobility - 10 reps"),
                WarmupItem("Light Band Pull-Aparts", "Rear delt warm-up - 20 reps")
            ),
            exercises = listOf(
                Exercise(
                    id = "mon_ex_1",
                    name = "Lat Pulldown (Wide Grip)",
                    targetMuscle = "Latissimus Dorsi",
                    sets = 3,
                    reps = "8 - 12 Reps",
                    note = "Chest up karke upper chest tak pull karein. Elbows ko niche aur andar squeeze karein.",
                    videoUrl = "https://media.musclewiki.com/media/uploads/videos/branded/male-lat-pulldown-front.mp4",
                    wikiUrl = "https://musclewiki.com/cables/male/lats/cable-lat-pulldown"
                ),
                Exercise(
                    id = "mon_ex_2",
                    name = "Seated Cable Row",
                    targetMuscle = "Mid Back & Rhomboids",
                    sets = 3,
                    reps = "10 - 12 Reps",
                    note = "Back straight rakhein. Navel (naabhi) ki taraf pull karein aur shoulder blades ko squeeze karein.",
                    videoUrl = "https://media.musclewiki.com/media/uploads/videos/branded/male-cable-seated-row-front.mp4",
                    wikiUrl = "https://musclewiki.com/cables/male/middle-back/cable-seated-row"
                ),
                Exercise(
                    id = "mon_ex_3",
                    name = "Face Pulls",
                    targetMuscle = "Rear Delts & Rotator Cuff",
                    sets = 3,
                    reps = "12 - 15 Reps",
                    note = "Rope ko aankho ke level par pull karein aur bahar spread karein. Shoulder health ke liye best.",
                    videoUrl = "https://media.musclewiki.com/media/uploads/videos/branded/male-cable-face-pull-front.mp4",
                    wikiUrl = "https://musclewiki.com/cables/male/shoulders/cable-face-pull"
                ),
                Exercise(
                    id = "mon_ex_4",
                    name = "Barbell Bicep Curl",
                    targetMuscle = "Biceps Brachii",
                    sets = 3,
                    reps = "10 - 12 Reps",
                    note = "Body swing mat karein. Top par bicep ko tight squeeze karein aur slow eccentric release karein.",
                    videoUrl = "https://media.musclewiki.com/media/uploads/videos/branded/male-barbell-curl-front.mp4",
                    wikiUrl = "https://musclewiki.com/barbell/male/biceps/barbell-curl"
                ),
                Exercise(
                    id = "mon_ex_5",
                    name = "Dumbbell Hammer Curls",
                    targetMuscle = "Brachialis & Forearms",
                    sets = 3,
                    reps = "12 - 15 Reps",
                    note = "Palms facing each other. Arms ki thickness aur forearms ke grip strength ke liye.",
                    videoUrl = "https://media.musclewiki.com/media/uploads/videos/branded/male-dumbbell-hammer-curl-front.mp4",
                    wikiUrl = "https://musclewiki.com/dumbbells/male/biceps/dumbbell-hammer-curl"
                )
            )
        ),

        // DAY 2: TUESDAY
        DayProtocol(
            dayOfWeekIndex = 2,
            dayName = "Tuesday",
            title = "Tuesday Leg Day Protocol",
            subtitle = "Quad sweeps, Hamstrings and Heavy Calves. Leg day builds discipline.",
            targetDuration = "50m",
            energyLevel = "90%",
            tag = "LEG DAY",
            warmups = listOf(
                WarmupItem("Bodyweight Air Squats", "15 slow control reps"),
                WarmupItem("Leg Swings (Front/Back & Side)", "Hip joint lubrication - 1 min"),
                WarmupItem("Glute Bridges", "Activation - 12 reps with 2s hold")
            ),
            exercises = listOf(
                Exercise(
                    id = "tue_ex_1",
                    name = "Barbell Back Squat",
                    targetMuscle = "Quadriceps & Glutes",
                    sets = 3,
                    reps = "8 - 10 Reps",
                    note = "Knees ko toes ke line mein rakhein. Parallel depth tak jayein aur heels se push karke uthein.",
                    videoUrl = "https://media.musclewiki.com/media/uploads/videos/branded/male-barbell-squat-front.mp4",
                    wikiUrl = "https://musclewiki.com/barbell/male/quads/barbell-squat"
                ),
                Exercise(
                    id = "tue_ex_2",
                    name = "Romanian Deadlift (RDL)",
                    targetMuscle = "Hamstrings & Lower Back",
                    sets = 3,
                    reps = "10 - 12 Reps",
                    note = "Hips ko peeche push karein, shins vertical. Hamstrings mein deep stretch mehsoos karein.",
                    videoUrl = "https://media.musclewiki.com/media/uploads/videos/branded/male-barbell-romanian-deadlift-front.mp4",
                    wikiUrl = "https://musclewiki.com/barbell/male/hamstrings/barbell-romanian-deadlift"
                ),
                Exercise(
                    id = "tue_ex_3",
                    name = "Leg Extensions",
                    targetMuscle = "Quad Isolation",
                    sets = 3,
                    reps = "12 - 15 Reps",
                    note = "Top par 1 second hold karein. Slow negative contraction maintain karein.",
                    videoUrl = "https://media.musclewiki.com/media/uploads/videos/branded/male-machine-leg-extension-front.mp4",
                    wikiUrl = "https://musclewiki.com/machine/male/quads/machine-leg-extension"
                ),
                Exercise(
                    id = "tue_ex_4",
                    name = "Lying / Seated Leg Curl",
                    targetMuscle = "Hamstrings Peak",
                    sets = 3,
                    reps = "12 - 15 Reps",
                    note = "Hips ko bench par flat rakhein, arch na karein. Full squeeze.",
                    videoUrl = "https://media.musclewiki.com/media/uploads/videos/branded/male-machine-leg-curl-front.mp4",
                    wikiUrl = "https://musclewiki.com/machine/male/hamstrings/machine-leg-curl"
                ),
                Exercise(
                    id = "tue_ex_5",
                    name = "Standing Calf Raises",
                    targetMuscle = "Gastrocnemius (Calves)",
                    sets = 4,
                    reps = "15 - 20 Reps",
                    note = "Full stretch at bottom, full squeeze at top. Bounce bilkul mat karein.",
                    videoUrl = "https://media.musclewiki.com/media/uploads/videos/branded/male-machine-calf-raise-front.mp4",
                    wikiUrl = "https://musclewiki.com/machine/male/calves/machine-calf-raise"
                )
            )
        ),

        // DAY 3: WEDNESDAY
        DayProtocol(
            dayOfWeekIndex = 3,
            dayName = "Wednesday",
            title = "Wednesday Active Recovery & Core",
            subtitle = "Core strengthening, full-body mobility & central nervous system recharge.",
            targetDuration = "35m",
            energyLevel = "85%",
            tag = "CORE & RECOVERY",
            warmups = listOf(
                WarmupItem("Light Foam Rolling", "Quads, lats and upper back - 5 mins"),
                WarmupItem("World's Greatest Stretch", "Hip and thoracic spine - 5 each side")
            ),
            exercises = listOf(
                Exercise(
                    id = "wed_ex_1",
                    name = "Hanging Knee / Leg Raises",
                    targetMuscle = "Lower Abs & Hip Flexors",
                    sets = 3,
                    reps = "12 - 15 Reps",
                    note = "Swing control karein. Pelvis ko upar curl karein taaki abs engage ho sakein.",
                    videoUrl = "https://media.musclewiki.com/media/uploads/videos/branded/male-bodyweight-hanging-leg-raise-front.mp4",
                    wikiUrl = "https://musclewiki.com/bodyweight/male/abdominals/hanging-leg-raise"
                ),
                Exercise(
                    id = "wed_ex_2",
                    name = "Elbow Plank Hold",
                    targetMuscle = "Core Stability & Transverse Abdominis",
                    sets = 3,
                    reps = "45 - 60s Hold",
                    note = "Glutes aur core tight. Body ek seedhi lakir mein honi chahiye, hips sag na karein.",
                    videoUrl = "https://media.musclewiki.com/media/uploads/videos/branded/male-bodyweight-plank-front.mp4",
                    wikiUrl = "https://musclewiki.com/bodyweight/male/abdominals/plank"
                ),
                Exercise(
                    id = "wed_ex_3",
                    name = "Russian Twists",
                    targetMuscle = "Obliques & Rotational Core",
                    sets = 3,
                    reps = "20 Reps (10 each side)",
                    note = "Feet off the floor ya lightly touching. Torso twist karein, sirf haath nahi.",
                    videoUrl = "https://media.musclewiki.com/media/uploads/videos/branded/male-bodyweight-russian-twist-front.mp4",
                    wikiUrl = "https://musclewiki.com/bodyweight/male/abdominals/russian-twist"
                ),
                Exercise(
                    id = "wed_ex_4",
                    name = "Full Body Dynamic Mobility Flow",
                    targetMuscle = "Joint Health & Flexibility",
                    sets = 3,
                    reps = "8 Mins Continuous",
                    note = "Pigeon pose, Cobra stretch, child's pose. Deep breathing ke saath perform karein.",
                    videoUrl = "https://media.musclewiki.com/media/uploads/videos/branded/male-bodyweight-cobra-stretch-front.mp4",
                    wikiUrl = "https://musclewiki.com/stretches"
                )
            )
        ),

        // DAY 4: THURSDAY
        DayProtocol(
            dayOfWeekIndex = 4,
            dayName = "Thursday",
            title = "Thursday HIIT & Conditioning",
            subtitle = "Cardiovascular capacity, fat burn sprint intervals & visceral endurance.",
            targetDuration = "30m",
            energyLevel = "90%",
            tag = "HIIT BURN",
            warmups = listOf(
                WarmupItem("Jumping Jacks & High Knees", "2 mins heart rate ramp up"),
                WarmupItem("Ankle & Wrist Rotations", "High impact preparation")
            ),
            exercises = listOf(
                Exercise(
                    id = "thu_ex_1",
                    name = "Tabata HIIT Burpees",
                    targetMuscle = "Full Body & Heart Rate Max",
                    sets = 4,
                    reps = "20s Work / 10s Rest",
                    note = "Chest floor par touch karein aur explosive jump ke saath finish karein. Timer audio chime use karein.",
                    videoUrl = "https://media.musclewiki.com/media/uploads/videos/branded/male-bodyweight-burpee-front.mp4",
                    wikiUrl = "https://musclewiki.com/bodyweight/male/quads/burpee"
                ),
                Exercise(
                    id = "thu_ex_2",
                    name = "Mountain Climbers",
                    targetMuscle = "Core & Conditioning",
                    sets = 4,
                    reps = "30s Sprint / 15s Rest",
                    note = "Plank position maintain karein aur rapid knees drive karein bina hips upar uthaye.",
                    videoUrl = "https://media.musclewiki.com/media/uploads/videos/branded/male-bodyweight-mountain-climber-front.mp4",
                    wikiUrl = "https://musclewiki.com/bodyweight/male/abdominals/mountain-climber"
                ),
                Exercise(
                    id = "thu_ex_3",
                    name = "Incline Treadmill Walk / Sprint",
                    targetMuscle = "Posterior Chain & VO2 Max",
                    sets = 3,
                    reps = "5 Mins Intervals",
                    note = "12-15% incline, 4-5 km/h speed. Hands mat pakdein, arms swing karein natural posture mein.",
                    videoUrl = "https://media.musclewiki.com/media/uploads/videos/branded/male-bodyweight-jumping-jacks-front.mp4",
                    wikiUrl = "https://musclewiki.com/cardio"
                )
            )
        ),

        // DAY 5: FRIDAY
        DayProtocol(
            dayOfWeekIndex = 5,
            dayName = "Friday",
            title = "Friday Upper Body Hypertrophy",
            subtitle = "Compound pressing and rowing synergy. Maximum pump and muscle hypertrophy.",
            targetDuration = "50m",
            energyLevel = "95%",
            tag = "UPPER POWER",
            warmups = listOf(
                WarmupItem("Scapular Pull-ups & Push-ups", "10 reps each shoulder activation"),
                WarmupItem("PVC / Band Pass-Throughs", "Shoulder range of motion - 15 reps")
            ),
            exercises = listOf(
                Exercise(
                    id = "fri_ex_1",
                    name = "Barbell Bent-Over Row",
                    targetMuscle = "Lats, Rhomboids & Spinal Erectors",
                    sets = 3,
                    reps = "8 - 10 Reps",
                    note = "45 degree back angle. Bar ko thighs ke paas se lower belly ki taraf pull karein.",
                    videoUrl = "https://media.musclewiki.com/media/uploads/videos/branded/male-barbell-bent-over-row-front.mp4",
                    wikiUrl = "https://musclewiki.com/barbell/male/middle-back/barbell-bent-over-row"
                ),
                Exercise(
                    id = "fri_ex_2",
                    name = "Dumbbell Flat Bench Press",
                    targetMuscle = "Pectoralis Major",
                    sets = 3,
                    reps = "8 - 12 Reps",
                    note = "Dumbbells allow deeper stretch than barbell. Bottom par pause karein, top par contract.",
                    videoUrl = "https://media.musclewiki.com/media/uploads/videos/branded/male-dumbbell-bench-press-front.mp4",
                    wikiUrl = "https://musclewiki.com/dumbbells/male/chest/dumbbell-bench-press"
                ),
                Exercise(
                    id = "fri_ex_3",
                    name = "Overhead Dumbbell Triceps Extension",
                    targetMuscle = "Triceps Long Head",
                    sets = 3,
                    reps = "10 - 12 Reps",
                    note = "Both hands se heavy dumbbell overhead pakdein. Elbows ko flare out na hone dein.",
                    videoUrl = "https://media.musclewiki.com/media/uploads/videos/branded/male-dumbbell-overhead-tricep-extension-front.mp4",
                    wikiUrl = "https://musclewiki.com/dumbbells/male/triceps/dumbbell-overhead-triceps-extension"
                ),
                Exercise(
                    id = "fri_ex_4",
                    name = "Incline Dumbbell Bicep Curl",
                    targetMuscle = "Biceps Long Head (Peak Stretch)",
                    sets = 3,
                    reps = "10 - 12 Reps",
                    note = "Incline bench par baithkar full stretch lein. Biceps peak develop karne ke liye top-tier exercise.",
                    videoUrl = "https://media.musclewiki.com/media/uploads/videos/branded/male-dumbbell-incline-curl-front.mp4",
                    wikiUrl = "https://musclewiki.com/dumbbells/male/biceps/dumbbell-incline-curl"
                ),
                Exercise(
                    id = "fri_ex_5",
                    name = "Cable Lateral Raise",
                    targetMuscle = "Lateral Deltoid Continuous Tension",
                    sets = 3,
                    reps = "12 - 15 Reps",
                    note = "Cable constant tension deti hai pure range of motion mein. Clean reps without jerk.",
                    videoUrl = "https://media.musclewiki.com/media/uploads/videos/branded/male-cable-lateral-raise-front.mp4",
                    wikiUrl = "https://musclewiki.com/cables/male/shoulders/cable-lateral-raise"
                )
            )
        ),

        // DAY 6: SATURDAY
        DayProtocol(
            dayOfWeekIndex = 6,
            dayName = "Saturday",
            title = "Saturday Posterior & Deadlift",
            subtitle = "Deadlifts, Glutes, Hamstrings & Unilateral balance. Closing the week with raw grit.",
            targetDuration = "55m",
            energyLevel = "100%",
            tag = "DEADLIFT GRIT",
            warmups = listOf(
                WarmupItem("Hip 90/90 Stretches", "Hip mobility - 1 min each side"),
                WarmupItem("Kettlebell / Dumbbell Swings", "Posterior chain activation - 15 reps")
            ),
            exercises = listOf(
                Exercise(
                    id = "sat_ex_1",
                    name = "Conventional Barbell Deadlift",
                    targetMuscle = "Posterior Chain, Glutes, Erectors & Traps",
                    sets = 3,
                    reps = "5 - 8 Reps",
                    note = "Barbell ko shin ke paas rakhein. Chest up, lats engaged, floor ko push karein jaise leg press ho.",
                    videoUrl = "https://media.musclewiki.com/media/uploads/videos/branded/male-barbell-deadlift-front.mp4",
                    wikiUrl = "https://musclewiki.com/barbell/male/hamstrings/barbell-deadlift"
                ),
                Exercise(
                    id = "sat_ex_2",
                    name = "Bulgarian Split Squat",
                    targetMuscle = "Single-leg Quad, Glute & Stabilizers",
                    sets = 3,
                    reps = "8 - 10 Reps / Leg",
                    note = "Back leg bench par. Front thigh 90 degree par descend karein. Balance aur hypertrophy king.",
                    videoUrl = "https://media.musclewiki.com/media/uploads/videos/branded/male-dumbbell-bulgarian-split-squat-front.mp4",
                    wikiUrl = "https://musclewiki.com/dumbbells/male/quads/dumbbell-bulgarian-split-squat"
                ),
                Exercise(
                    id = "sat_ex_3",
                    name = "Dumbbell Walking Lunges",
                    targetMuscle = "Glutes, Hamstrings & Quads",
                    sets = 3,
                    reps = "12 Steps Each Leg",
                    note = "Torso slightly leaned forward to target glutes. Knees ground ko gently touch karein.",
                    videoUrl = "https://media.musclewiki.com/media/uploads/videos/branded/male-dumbbell-lunge-front.mp4",
                    wikiUrl = "https://musclewiki.com/dumbbells/male/quads/dumbbell-lunge"
                ),
                Exercise(
                    id = "sat_ex_4",
                    name = "Standing Seated Calf Burnout",
                    targetMuscle = "Calves & Tibialis",
                    sets = 4,
                    reps = "15 - 20 Reps",
                    note = "Final leg pump. Hold bottom stretch for 2s every rep.",
                    videoUrl = "https://media.musclewiki.com/media/uploads/videos/branded/male-machine-calf-raise-front.mp4",
                    wikiUrl = "https://musclewiki.com/machine/male/calves/machine-calf-raise"
                )
            )
        )
    )

    fun getProtocolForDayOfWeek(dayIndex: Int): DayProtocol {
        val safeIndex = (dayIndex % 7 + 7) % 7
        return protocols.firstOrNull { it.dayOfWeekIndex == safeIndex } ?: protocols[0]
    }
}
