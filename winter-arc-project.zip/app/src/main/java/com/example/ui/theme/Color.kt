package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Winter Arc // iOS 26 Obsidian Glassmorphism Palette
val ObsidianBlack = Color(0xFF020306)
val CardBackground = Color(0x8C0B0F19) // High-translucency obsidian glass (~55% alpha)
val CardBackgroundElevated = Color(0x9E101624) // Elevated translucent glass (~62% alpha)
val CardBackgroundSolid = Color(0xFF0C101B)

// Consistent Neon Cyan & Specular Borders
val CardBorder = Color(0x5938BDF8) // Neon Cyan border (#38BDF8 at 35% alpha)
val CardBorderBright = Color(0x8C38BDF8) // High-intensity Neon Cyan border (55% alpha)
val CardShine = Color(0x1438BDF8) // Frosted cyan internal sheen

// Neon & Accents
val AccentFlame = Color(0xFFFF5E00) // #FF5E00 Flame Orange
val AccentFlameGlow = Color(0x38FF5E00)
val AccentFrost = Color(0xFF38BDF8) // #38BDF8 Neon Sky Cyan
val AccentFrostGlow = Color(0x3838BDF8)
val AccentToxic = Color(0xFF22C55E) // #22C55E Toxic Green
val AccentIndigo = Color(0xFF6366F1) // #6366F1 Indigo
val AccentRed = Color(0xFFEF4444)

// Typography
val TextPrimary = Color(0xFFF8FAFC)
val TextSecondary = Color(0xFF94A3B8)
val TextTertiary = Color(0xFF64748B)

// Glass Surfaces
val GlassSurfaceDark = Color(0x94090D16)
val GlassSurfaceOverlay = Color(0xD9080B13)
