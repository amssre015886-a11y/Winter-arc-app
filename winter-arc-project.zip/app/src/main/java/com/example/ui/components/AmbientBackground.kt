package com.example.ui.components

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import com.example.ui.theme.AccentFlame
import com.example.ui.theme.AccentFrost
import com.example.ui.theme.AccentIndigo
import com.example.ui.theme.ObsidianBlack
import kotlin.random.Random

private data class AmbientParticle(
    val xRatio: Float,
    val initialYRatio: Float,
    val radius: Float,
    val speed: Float,
    val baseAlpha: Float,
    val isFlame: Boolean
)

@Composable
fun AmbientBackground(
    modifier: Modifier = Modifier
) {
    val transition = rememberInfiniteTransition(label = "ambient_bg")

    val frostShiftX = transition.animateFloat(
        initialValue = -0.18f,
        targetValue = 0.18f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 7500, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "frost_x"
    )
    val frostShiftY = transition.animateFloat(
        initialValue = -0.06f,
        targetValue = 0.10f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 6000, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "frost_y"
    )

    val flameShiftX = transition.animateFloat(
        initialValue = 0.20f,
        targetValue = -0.20f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 8800, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "flame_x"
    )
    val flameShiftY = transition.animateFloat(
        initialValue = 0.06f,
        targetValue = -0.06f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 7000, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "flame_y"
    )

    val particleProgress = transition.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 14000, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "particles"
    )

    val particles = remember {
        val rand = Random(42)
        List(28) {
            AmbientParticle(
                xRatio = rand.nextFloat(),
                initialYRatio = rand.nextFloat(),
                radius = rand.nextFloat() * 2.4f + 1.0f,
                speed = rand.nextFloat() * 0.65f + 0.25f,
                baseAlpha = rand.nextFloat() * 0.38f + 0.14f,
                isFlame = rand.nextInt(3) == 0 // 2/3 neon cyan, 1/3 flame
            )
        }
    }

    Canvas(modifier = modifier.fillMaxSize()) {
        val width = size.width
        val height = size.height

        // 1. Deep iOS 26 Obsidian Base
        drawRect(color = ObsidianBlack)

        // 2. High-diffusion Neon Cyan Aurora (Top)
        val frostCenter = Offset(
            x = width * (0.48f + frostShiftX.value),
            y = height * (0.08f + frostShiftY.value)
        )
        val frostRadius = width * 0.92f
        drawCircle(
            brush = Brush.radialGradient(
                colors = listOf(
                    AccentFrost.copy(alpha = 0.22f),
                    AccentFrost.copy(alpha = 0.09f),
                    Color.Transparent
                ),
                center = frostCenter,
                radius = frostRadius
            ),
            center = frostCenter,
            radius = frostRadius
        )

        // 3. Mid-screen Cyan-Indigo Bokeh Haze (illuminates translucent middle cards)
        val midCenter = Offset(
            x = width * (0.22f - frostShiftX.value * 0.6f),
            y = height * 0.46f
        )
        val midRadius = width * 0.78f
        drawCircle(
            brush = Brush.radialGradient(
                colors = listOf(
                    AccentFrost.copy(alpha = 0.12f),
                    AccentIndigo.copy(alpha = 0.06f),
                    Color.Transparent
                ),
                center = midCenter,
                radius = midRadius
            ),
            center = midCenter,
            radius = midRadius
        )

        // 4. Flame Orange & Cyan Sub-Aurora (Bottom)
        val flameCenter = Offset(
            x = width * (0.55f + flameShiftX.value),
            y = height * (0.88f + flameShiftY.value)
        )
        val flameRadius = width * 0.90f
        drawCircle(
            brush = Brush.radialGradient(
                colors = listOf(
                    AccentFlame.copy(alpha = 0.15f),
                    AccentFrost.copy(alpha = 0.05f),
                    Color.Transparent
                ),
                center = flameCenter,
                radius = flameRadius
            ),
            center = flameCenter,
            radius = flameRadius
        )

        // 5. Floating atmospheric micro-particles
        particles.forEach { p ->
            val curY = ((p.initialYRatio - (particleProgress.value * p.speed)) % 1f + 1f) % 1f
            val px = p.xRatio * width
            val py = curY * height
            val color = if (p.isFlame) AccentFlame else AccentFrost
            drawCircle(
                color = color.copy(alpha = p.baseAlpha),
                radius = p.radius,
                center = Offset(px, py)
            )
        }
    }
}
