package com.example.ui.components

import android.content.Intent
import android.net.Uri
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.OpenInNew
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.SlowMotionVideo
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.model.Exercise
import com.example.ui.theme.AccentFlame
import com.example.ui.theme.AccentFrost
import com.example.ui.theme.AccentToxic
import com.example.ui.theme.CardBorder
import com.example.ui.theme.GlassSurfaceOverlay
import com.example.ui.theme.ObsidianBlack
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.theme.TextTertiary
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin

@Composable
fun VideoPlayerDialog(
    exercise: Exercise,
    onDismiss: () -> Unit
) {
    val context = LocalContext.current
    var isPlaying by remember { mutableStateOf(true) }
    var isSlowMo by remember { mutableStateOf(false) }

    val transition = rememberInfiniteTransition(label = "biomech_loop")
    val rawCycle by transition.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(
                durationMillis = if (isSlowMo) 6400 else 3200,
                easing = LinearEasing
            ),
            repeatMode = RepeatMode.Restart
        ),
        label = "cycle"
    )

    val pausedCycle by remember { mutableStateOf(0.35f) }
    val activeCycle = if (isPlaying) rawCycle else pausedCycle

    // Smooth 0..1..0 rep progress wave
    val repProgress = ((1f - cos(activeCycle * 2f * PI.toFloat())) / 2f).coerceIn(0f, 1f)

    // Determine biomechanical phase label
    val phaseLabel = when {
        activeCycle < 0.40f -> "CONCENTRIC DRIVE (EXHALE)"
        activeCycle < 0.55f -> "PEAK CONTRACTION (1s HOLD)"
        activeCycle < 0.90f -> "ECCENTRIC CONTROL (INHALE)"
        else -> "BOTTOM STRETCH"
    }

    val phaseColor = when {
        activeCycle < 0.40f -> AccentFlame
        activeCycle < 0.55f -> AccentToxic
        else -> AccentFrost
    }

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(
            dismissOnBackPress = true,
            dismissOnClickOutside = true,
            usePlatformDefaultWidth = false
        )
    ) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(Color.Black.copy(alpha = 0.88f))
                .clickable { onDismiss() }
                .padding(16.dp),
            contentAlignment = Alignment.Center
        ) {
            Surface(
                modifier = Modifier
                    .fillMaxWidth(0.95f)
                    .clip(RoundedCornerShape(24.dp))
                    .border(1.dp, CardBorder, RoundedCornerShape(24.dp))
                    .clickable(enabled = false) {},
                color = GlassSurfaceOverlay,
                shadowElevation = 24.dp
            ) {
                Column(
                    modifier = Modifier.fillMaxWidth()
                ) {
                    // Header Bar
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 18.dp, vertical = 14.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = exercise.name,
                                color = TextPrimary,
                                fontSize = 16.sp,
                                fontWeight = FontWeight.Bold,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                            Text(
                                text = exercise.targetMuscle,
                                color = AccentFrost,
                                fontSize = 12.sp,
                                fontFamily = FontFamily.Monospace,
                                fontWeight = FontWeight.Medium
                            )
                        }

                        IconButton(
                            onClick = onDismiss,
                            modifier = Modifier
                                .size(34.dp)
                                .clip(CircleShape)
                                .background(Color.White.copy(alpha = 0.08f))
                        ) {
                            Icon(
                                imageVector = Icons.Default.Close,
                                contentDescription = "Close",
                                tint = Color.White,
                                modifier = Modifier.size(18.dp)
                            )
                        }
                    }

                    // Native 60FPS Biomechanical Motion Viewport
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(265.dp)
                            .background(ObsidianBlack),
                        contentAlignment = Alignment.Center
                    ) {
                        Canvas(modifier = Modifier.fillMaxSize()) {
                            drawBiomechanicalVisualizer(
                                exercise = exercise,
                                progress = repProgress
                            )
                        }

                        // Top-left Live Phase Indicator
                        Box(
                            modifier = Modifier
                                .align(Alignment.TopStart)
                                .padding(12.dp)
                                .clip(RoundedCornerShape(8.dp))
                                .background(Color.Black.copy(alpha = 0.72f))
                                .border(1.dp, phaseColor.copy(alpha = 0.45f), RoundedCornerShape(8.dp))
                                .padding(horizontal = 10.dp, vertical = 5.dp)
                        ) {
                            Text(
                                text = phaseLabel,
                                color = phaseColor,
                                fontSize = 10.sp,
                                fontFamily = FontFamily.Monospace,
                                fontWeight = FontWeight.ExtraBold
                            )
                        }

                        // Top-right MuscleWiki HD Badge
                        Box(
                            modifier = Modifier
                                .align(Alignment.TopEnd)
                                .padding(12.dp)
                                .clip(RoundedCornerShape(8.dp))
                                .background(Color.Black.copy(alpha = 0.72f))
                                .border(1.dp, Color.White.copy(alpha = 0.2f), RoundedCornerShape(8.dp))
                                .padding(horizontal = 8.dp, vertical = 4.dp)
                        ) {
                            Text(
                                text = "MUSCLEWIKI MOTION",
                                color = AccentFlame,
                                fontSize = 10.sp,
                                fontFamily = FontFamily.Monospace,
                                fontWeight = FontWeight.Bold
                            )
                        }

                        // Bottom Control Overlay (Play/Pause, Slow-Mo, Tempo Progress)
                        Row(
                            modifier = Modifier
                                .align(Alignment.BottomCenter)
                                .fillMaxWidth()
                                .background(
                                    Brush.verticalGradient(
                                        listOf(Color.Transparent, Color.Black.copy(alpha = 0.85f))
                                    )
                                )
                                .padding(horizontal = 14.dp, vertical = 10.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            // Play / Pause pill
                            Row(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(999.dp))
                                    .background(Color.White.copy(alpha = 0.12f))
                                    .clickable { isPlaying = !isPlaying }
                                    .padding(horizontal = 12.dp, vertical = 6.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(
                                    imageVector = if (isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow,
                                    contentDescription = if (isPlaying) "Pause" else "Play",
                                    tint = Color.White,
                                    modifier = Modifier.size(15.dp)
                                )
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(
                                    text = if (isPlaying) "PAUSE" else "PLAY",
                                    color = Color.White,
                                    fontSize = 10.sp,
                                    fontFamily = FontFamily.Monospace,
                                    fontWeight = FontWeight.Bold
                                )
                            }

                            // Rep Contraction Meter
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                modifier = Modifier
                                    .weight(1f)
                                    .padding(horizontal = 12.dp)
                            ) {
                                Box(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .height(6.dp)
                                        .clip(RoundedCornerShape(999.dp))
                                        .background(Color.White.copy(alpha = 0.12f))
                                ) {
                                    Box(
                                        modifier = Modifier
                                            .fillMaxWidth(repProgress)
                                            .height(6.dp)
                                            .clip(RoundedCornerShape(999.dp))
                                            .background(
                                                Brush.horizontalGradient(
                                                    listOf(AccentFrost, AccentFlame)
                                                )
                                            )
                                    )
                                }
                            }

                            // Slow-Mo toggle pill
                            Row(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(999.dp))
                                    .background(
                                        if (isSlowMo) AccentFlame.copy(alpha = 0.25f)
                                        else Color.White.copy(alpha = 0.12f)
                                    )
                                    .border(
                                        1.dp,
                                        if (isSlowMo) AccentFlame else Color.Transparent,
                                        RoundedCornerShape(999.dp)
                                    )
                                    .clickable { isSlowMo = !isSlowMo }
                                    .padding(horizontal = 10.dp, vertical = 6.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(
                                    imageVector = Icons.Default.SlowMotionVideo,
                                    contentDescription = "Speed",
                                    tint = if (isSlowMo) AccentFlame else TextSecondary,
                                    modifier = Modifier.size(14.dp)
                                )
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(
                                    text = if (isSlowMo) "0.5x" else "1.0x",
                                    color = if (isSlowMo) AccentFlame else TextPrimary,
                                    fontSize = 10.sp,
                                    fontFamily = FontFamily.Monospace,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    }

                    // Form notes & external guide row
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(18.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "FORM INSTRUCTION:",
                                color = AccentFlame,
                                fontSize = 11.sp,
                                fontFamily = FontFamily.Monospace,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = "${exercise.sets} SETS × ${exercise.reps.uppercase()}",
                                color = TextTertiary,
                                fontSize = 10.sp,
                                fontFamily = FontFamily.Monospace,
                                fontWeight = FontWeight.Bold
                            )
                        }
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = exercise.note,
                            color = TextSecondary,
                            fontSize = 13.sp,
                            lineHeight = 18.sp
                        )

                        Spacer(modifier = Modifier.height(14.dp))

                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(12.dp))
                                .background(Color.White.copy(alpha = 0.04f))
                                .border(1.dp, Color.White.copy(alpha = 0.08f), RoundedCornerShape(12.dp))
                                .clickable {
                                    val intent = Intent(Intent.ACTION_VIEW, Uri.parse(exercise.wikiUrl))
                                    context.startActivity(intent)
                                }
                                .padding(horizontal = 14.dp, vertical = 10.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "Open Full Video & Guide on MuscleWiki.com",
                                color = AccentFrost,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.SemiBold
                            )
                            Icon(
                                imageVector = Icons.Default.OpenInNew,
                                contentDescription = null,
                                tint = AccentFrost,
                                modifier = Modifier.size(16.dp)
                            )
                        }
                    }
                }
            }
        }
    }
}

private fun DrawScope.drawBiomechanicalVisualizer(
    exercise: Exercise,
    progress: Float
) {
    val w = size.width
    val h = size.height
    val cx = w / 2f
    val cy = h / 2f

    // Subtle biomechanics grid lines
    val gridStep = 28.dp.toPx()
    var gx = gridStep
    while (gx < w) {
        drawLine(
            color = Color.White.copy(alpha = 0.03f),
            start = Offset(gx, 0f),
            end = Offset(gx, h),
            strokeWidth = 1f
        )
        gx += gridStep
    }
    var gy = gridStep
    while (gy < h) {
        drawLine(
            color = Color.White.copy(alpha = 0.03f),
            start = Offset(0f, gy),
            end = Offset(w, gy),
            strokeWidth = 1f
        )
        gy += gridStep
    }

    // Ambient target muscle aura glow in background
    drawCircle(
        brush = Brush.radialGradient(
            colors = listOf(
                AccentFlame.copy(alpha = 0.14f + 0.14f * progress),
                AccentFrost.copy(alpha = 0.06f),
                Color.Transparent
            ),
            center = Offset(cx, cy),
            radius = w * 0.42f
        ),
        center = Offset(cx, cy),
        radius = w * 0.42f
    )

    val nameLower = exercise.name.lowercase()
    val boneStroke = 7.dp.toPx()
    val jointRadius = 5.dp.toPx()

    when {
        // 1. SQUAT / LUNGE / LEG PRESS
        nameLower.contains("squat") || nameLower.contains("lunge") -> {
            val floorY = h * 0.78f
            // Floor line
            drawLine(
                color = AccentFrost.copy(alpha = 0.35f),
                start = Offset(cx - 90.dp.toPx(), floorY),
                end = Offset(cx + 90.dp.toPx(), floorY),
                strokeWidth = 2.dp.toPx()
            )

            // progress 0 = bottom squat, 1 = standing lockout
            val hipDrop = (1f - progress) * 42.dp.toPx()
            val ankle = Offset(cx + 6.dp.toPx(), floorY)
            val knee = Offset(cx + 26.dp.toPx() * (1f - progress * 0.6f), floorY - 46.dp.toPx())
            val hip = Offset(cx - 20.dp.toPx() * (1f - progress * 0.5f), floorY - 88.dp.toPx() + hipDrop)
            val shoulder = Offset(cx + 8.dp.toPx(), hip.y - 54.dp.toPx())
            val head = Offset(shoulder.x + 4.dp.toPx(), shoulder.y - 20.dp.toPx())

            // Target Muscle Highlight (Quads & Glutes)
            drawLine(
                color = AccentFlame.copy(alpha = 0.45f + 0.45f * (1f - progress)),
                start = hip,
                end = knee,
                strokeWidth = boneStroke * 2.2f,
                cap = StrokeCap.Round
            )

            // Skeleton limbs
            drawLimb(ankle, knee, boneStroke)
            drawLimb(knee, hip, boneStroke)
            drawLimb(hip, shoulder, boneStroke)
            drawCircle(color = TextPrimary, radius = 12.dp.toPx(), center = head)

            // Barbell across traps
            drawCircle(
                color = AccentFlame,
                radius = 12.dp.toPx(),
                center = shoulder
            )
            drawCircle(
                color = Color.White,
                radius = 5.dp.toPx(),
                center = shoulder
            )
        }

        // 2. DEADLIFT / RDL / BENT-OVER ROW
        nameLower.contains("deadlift") || nameLower.contains("row") -> {
            val floorY = h * 0.78f
            drawLine(
                color = AccentFrost.copy(alpha = 0.35f),
                start = Offset(cx - 90.dp.toPx(), floorY),
                end = Offset(cx + 90.dp.toPx(), floorY),
                strokeWidth = 2.dp.toPx()
            )

            val hingeAngle = (1f - progress) * 0.85f // radians forward hinge
            val ankle = Offset(cx, floorY)
            val knee = Offset(cx + 8.dp.toPx(), floorY - 44.dp.toPx())
            val hip = Offset(cx - 22.dp.toPx() * (1f - progress * 0.6f), knee.y - 44.dp.toPx())
            val torsoLen = 58.dp.toPx()
            val shoulder = Offset(
                hip.x + sin(hingeAngle) * torsoLen,
                hip.y - cos(hingeAngle) * torsoLen
            )
            val head = Offset(
                shoulder.x + sin(hingeAngle) * 20.dp.toPx(),
                shoulder.y - cos(hingeAngle) * 20.dp.toPx()
            )

            // Posterior chain highlight
            drawLine(
                color = AccentFlame.copy(alpha = 0.5f + 0.4f * progress),
                start = hip,
                end = shoulder,
                strokeWidth = boneStroke * 2.1f,
                cap = StrokeCap.Round
            )

            drawLimb(ankle, knee, boneStroke)
            drawLimb(knee, hip, boneStroke)
            drawLimb(hip, shoulder, boneStroke)
            drawCircle(color = TextPrimary, radius = 12.dp.toPx(), center = head)

            // Arms & Barbell path
            val handY = if (nameLower.contains("row")) {
                shoulder.y + 42.dp.toPx() - (progress * 26.dp.toPx())
            } else {
                shoulder.y + 48.dp.toPx()
            }
            val hand = Offset(shoulder.x + 4.dp.toPx(), handY)
            drawLimb(shoulder, hand, boneStroke * 0.85f)
            drawCircle(color = AccentFlame, radius = 14.dp.toPx(), center = hand)
            drawCircle(color = Color.White, radius = jointRadius, center = hand)
        }

        // 3. OVERHEAD PRESS / LATERAL RAISE / PULLDOWN
        nameLower.contains("overhead") || nameLower.contains("lateral") || nameLower.contains("pulldown") || nameLower.contains("face pull") -> {
            val torsoTop = Offset(cx, cy - 28.dp.toPx())
            val torsoBottom = Offset(cx, cy + 55.dp.toPx())
            val head = Offset(cx, torsoTop.y - 24.dp.toPx())

            // Torso & Head
            drawLimb(torsoBottom, torsoTop, boneStroke * 1.4f)
            drawCircle(color = TextPrimary, radius = 13.dp.toPx(), center = head)

            val shoulderSpan = 30.dp.toPx()
            val leftShoulder = Offset(cx - shoulderSpan, torsoTop.y + 6.dp.toPx())
            val rightShoulder = Offset(cx + shoulderSpan, torsoTop.y + 6.dp.toPx())
            drawLimb(leftShoulder, rightShoulder, boneStroke)

            // Deltoid / Lat Glow
            drawCircle(color = AccentFlame.copy(alpha = 0.65f), radius = 12.dp.toPx(), center = leftShoulder)
            drawCircle(color = AccentFlame.copy(alpha = 0.65f), radius = 12.dp.toPx(), center = rightShoulder)

            if (nameLower.contains("lateral")) {
                // Lateral raise arc
                val armLen = 48.dp.toPx()
                val angle = (0.25f + progress * 1.25f) // down by side to horizontal
                val leftHand = Offset(
                    leftShoulder.x - sin(angle) * armLen,
                    leftShoulder.y + cos(angle) * armLen
                )
                val rightHand = Offset(
                    rightShoulder.x + sin(angle) * armLen,
                    rightShoulder.y + cos(angle) * armLen
                )
                drawLimb(leftShoulder, leftHand, boneStroke * 0.9f)
                drawLimb(rightShoulder, rightHand, boneStroke * 0.9f)
                drawDumbbell(leftHand)
                drawDumbbell(rightHand)
            } else {
                // Vertical press or pulldown
                val isPull = nameLower.contains("pull")
                val effectiveProg = if (isPull) (1f - progress) else progress
                val elbowY = torsoTop.y + 18.dp.toPx() - (effectiveProg * 28.dp.toPx())
                val handY = elbowY - 32.dp.toPx() - (effectiveProg * 14.dp.toPx())

                val leftElbow = Offset(leftShoulder.x - 16.dp.toPx(), elbowY)
                val rightElbow = Offset(rightShoulder.x + 16.dp.toPx(), elbowY)
                val leftHand = Offset(leftShoulder.x - 12.dp.toPx(), handY)
                val rightHand = Offset(rightShoulder.x + 12.dp.toPx(), handY)

                drawLimb(leftShoulder, leftElbow, boneStroke * 0.9f)
                drawLimb(leftElbow, leftHand, boneStroke * 0.85f)
                drawLimb(rightShoulder, rightElbow, boneStroke * 0.9f)
                drawLimb(rightElbow, rightHand, boneStroke * 0.85f)

                if (isPull) {
                    // Wide bar
                    drawLine(
                        color = AccentFrost,
                        start = Offset(leftHand.x - 16.dp.toPx(), handY),
                        end = Offset(rightHand.x + 16.dp.toPx(), handY),
                        strokeWidth = 5.dp.toPx(),
                        cap = StrokeCap.Round
                    )
                } else {
                    drawDumbbell(leftHand)
                    drawDumbbell(rightHand)
                }
            }
        }

        // 4. BICEP CURL / TRICEP PUSHDOWN
        nameLower.contains("curl") || nameLower.contains("tricep") || nameLower.contains("pushdown") -> {
            val isTricep = nameLower.contains("tricep") || nameLower.contains("pushdown")
            val shoulder = Offset(cx - 12.dp.toPx(), cy - 34.dp.toPx())
            val hip = Offset(cx - 14.dp.toPx(), cy + 48.dp.toPx())
            val head = Offset(shoulder.x + 2.dp.toPx(), shoulder.y - 24.dp.toPx())
            val elbow = Offset(shoulder.x + 6.dp.toPx(), shoulder.y + 38.dp.toPx())

            drawLimb(hip, shoulder, boneStroke * 1.3f)
            drawCircle(color = TextPrimary, radius = 13.dp.toPx(), center = head)

            // Highlight upper arm (Bicep or Tricep)
            drawLine(
                color = AccentFlame.copy(alpha = 0.5f + 0.45f * progress),
                start = shoulder,
                end = elbow,
                strokeWidth = boneStroke * 2.2f,
                cap = StrokeCap.Round
            )
            drawLimb(shoulder, elbow, boneStroke)

            val forearmLen = 40.dp.toPx()
            // For curl: 0 = down, 1 = curled up; for pushdown: 0 = bent up, 1 = locked down
            val angle = if (isTricep) {
                (2.2f - progress * 1.8f)
            } else {
                (0.4f + progress * 2.0f)
            }
            val hand = Offset(
                elbow.x + sin(angle) * forearmLen,
                elbow.y + cos(angle) * forearmLen
            )
            drawLimb(elbow, hand, boneStroke * 0.9f)
            drawDumbbell(hand)
        }

        // 5. CHEST PRESS (INCLINE / FLAT BENCH) & DEFAULT
        else -> {
            val isIncline = nameLower.contains("incline")
            val benchY = cy + 28.dp.toPx()
            // Draw Bench
            if (isIncline) {
                drawLine(
                    color = TextTertiary.copy(alpha = 0.5f),
                    start = Offset(cx - 48.dp.toPx(), benchY + 18.dp.toPx()),
                    end = Offset(cx + 36.dp.toPx(), benchY - 22.dp.toPx()),
                    strokeWidth = 6.dp.toPx(),
                    cap = StrokeCap.Round
                )
            } else {
                drawLine(
                    color = TextTertiary.copy(alpha = 0.5f),
                    start = Offset(cx - 56.dp.toPx(), benchY),
                    end = Offset(cx + 56.dp.toPx(), benchY),
                    strokeWidth = 6.dp.toPx(),
                    cap = StrokeCap.Round
                )
            }

            val shoulder = Offset(cx, benchY - 12.dp.toPx())
            val pressHeight = 20.dp.toPx() + progress * 52.dp.toPx()
            val hand = Offset(cx, shoulder.y - pressHeight)
            val elbow = Offset(cx + 22.dp.toPx() * (1f - progress * 0.65f), (shoulder.y + hand.y) / 2f + 10.dp.toPx())

            // Pectoral Glow
            drawCircle(
                color = AccentFlame.copy(alpha = 0.5f + 0.45f * progress),
                radius = 18.dp.toPx(),
                center = shoulder
            )

            drawLimb(shoulder, elbow, boneStroke)
            drawLimb(elbow, hand, boneStroke * 0.9f)

            // Barbell / Dumbbell weight plate
            drawCircle(color = AccentFlame, radius = 15.dp.toPx(), center = hand)
            drawCircle(
                color = AccentFrost,
                radius = 15.dp.toPx(),
                center = hand,
                style = Stroke(width = 2.dp.toPx())
            )
            drawCircle(color = Color.White, radius = jointRadius, center = hand)
        }
    }
}

private fun DrawScope.drawLimb(start: Offset, end: Offset, strokeWidth: Float) {
    drawLine(
        color = TextPrimary,
        start = start,
        end = end,
        strokeWidth = strokeWidth,
        cap = StrokeCap.Round
    )
    drawCircle(color = AccentFrost, radius = strokeWidth * 0.55f, center = start)
    drawCircle(color = AccentFrost, radius = strokeWidth * 0.55f, center = end)
}

private fun DrawScope.drawDumbbell(center: Offset) {
    drawCircle(
        color = AccentFlame,
        radius = 8.dp.toPx(),
        center = center
    )
    drawCircle(
        color = Color.White,
        radius = 3.dp.toPx(),
        center = center
    )
}
