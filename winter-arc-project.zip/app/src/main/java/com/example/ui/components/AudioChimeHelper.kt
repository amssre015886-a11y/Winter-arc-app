package com.example.ui.components

import android.content.Context
import android.media.AudioManager
import android.media.ToneGenerator
import android.os.Build
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import android.util.Log

object AudioChimeHelper {
    private var toneGen: ToneGenerator? = null

    init {
        try {
            toneGen = ToneGenerator(AudioManager.STREAM_MUSIC, 85)
        } catch (e: Exception) {
            Log.e("AudioChimeHelper", "ToneGenerator init failed", e)
        }
    }

    fun playCountdownBeep(context: Context, isFinal: Boolean = false) {
        try {
            if (isFinal) {
                toneGen?.startTone(ToneGenerator.TONE_PROP_PROMPT, 500)
                vibrate(context, 400)
            } else {
                toneGen?.startTone(ToneGenerator.TONE_PROP_BEEP, 150)
                vibrate(context, 70)
            }
        } catch (e: Exception) {
            Log.e("AudioChimeHelper", "playCountdownBeep failed", e)
        }
    }

    fun playTabataPhaseChime(context: Context, isWork: Boolean) {
        try {
            if (isWork) {
                // High energetic double beep for WORK
                toneGen?.startTone(ToneGenerator.TONE_CDMA_ALERT_NETWORK_LITE, 350)
                vibrate(context, 250)
            } else {
                // Lower rest tone
                toneGen?.startTone(ToneGenerator.TONE_PROP_BEEP2, 300)
                vibrate(context, 150)
            }
        } catch (e: Exception) {
            Log.e("AudioChimeHelper", "playTabataPhaseChime failed", e)
        }
    }

    fun playWaterChime(context: Context) {
        try {
            toneGen?.startTone(ToneGenerator.TONE_PROP_ACK, 200)
            vibrate(context, 80)
        } catch (e: Exception) {
            Log.e("AudioChimeHelper", "playWaterChime failed", e)
        }
    }

    fun vibrate(context: Context, durationMs: Long) {
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                val vibratorManager = context.getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as? VibratorManager
                vibratorManager?.defaultVibrator?.vibrate(
                    VibrationEffect.createOneShot(durationMs, VibrationEffect.DEFAULT_AMPLITUDE)
                )
            } else {
                @Suppress("DEPRECATION")
                val vibrator = context.getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    vibrator?.vibrate(VibrationEffect.createOneShot(durationMs, VibrationEffect.DEFAULT_AMPLITUDE))
                } else {
                    @Suppress("DEPRECATION")
                    vibrator?.vibrate(durationMs)
                }
            }
        } catch (e: Exception) {
            Log.e("AudioChimeHelper", "Vibrate failed", e)
        }
    }
}
