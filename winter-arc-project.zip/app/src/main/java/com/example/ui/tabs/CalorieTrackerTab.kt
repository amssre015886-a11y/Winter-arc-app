package com.example.ui.tabs

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.spring
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.DeleteOutline
import androidx.compose.material.icons.filled.FitnessCenter
import androidx.compose.material.icons.filled.Grain
import androidx.compose.material.icons.filled.LocalFireDepartment
import androidx.compose.material.icons.filled.NightlightRound
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.RemoveCircleOutline
import androidx.compose.material.icons.filled.Restaurant
import androidx.compose.material.icons.filled.SwapHoriz
import androidx.compose.material.icons.filled.WaterDrop
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.ai.CoachStreamUiState
import com.example.ai.FoodAnalysisUiState
import com.example.ai.WinterArcAiViewModel
import com.example.data.ProtocolPreferences
import com.example.model.DefaultNutritionData
import com.example.model.FoodItem
import com.example.model.MealCategory
import com.example.model.MealItemStatus
import com.example.ui.components.AppleBentoMetricCard
import com.example.ui.components.AppleLiveStatusBadge
import com.example.ui.components.AppleOrangeActionPillButton
import com.example.ui.components.AudioChimeHelper
import com.example.ui.components.appleSpecularBorderBrush
import com.example.ui.theme.AccentFlame
import com.example.ui.theme.AccentFrost
import com.example.ui.theme.AccentIndigo
import com.example.ui.theme.AccentRed
import com.example.ui.theme.AccentToxic
import com.example.ui.theme.GlassSurfaceOverlay
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.theme.TextTertiary
import kotlin.random.Random

@Composable
fun CalorieTrackerTab(
    protocolPrefs: ProtocolPreferences,
    aiViewModel: WinterArcAiViewModel,
    currentWorkoutTitle: String,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val meals by protocolPrefs.mealsFlow.collectAsState()
    val completedSets by protocolPrefs.completedSetsCountFlow.collectAsState()
    val waterMl by protocolPrefs.waterIntakeFlow.collectAsState()
    val coachStreamState by aiViewModel.coachStreamState.collectAsState()

    var selectedCategoryFilter by remember { mutableStateOf<MealCategory?>(null) } // null = All
    var showAddFoodDialog by remember { mutableStateOf(false) }
    var dialogInitialCategory by remember { mutableStateOf(MealCategory.LUNCH) }
    var dialogReplacedItemName by remember { mutableStateOf<String?>(null) }

    // Compute live macros from EATEN items
    val eatenMeals = remember(meals) { meals.filter { it.status == MealItemStatus.EATEN } }
    val skippedMeals = remember(meals) { meals.filter { it.status == MealItemStatus.SKIPPED } }

    val totalCalories = remember(eatenMeals) { eatenMeals.sumOf { it.calories } }
    val totalProtein = remember(eatenMeals) { eatenMeals.sumOf { it.proteinGrams } }
    val totalCarbs = remember(eatenMeals) { eatenMeals.sumOf { it.carbsGrams } }
    val totalFats = remember(eatenMeals) { eatenMeals.sumOf { it.fatsGrams } }

    val filteredMeals = remember(meals, selectedCategoryFilter) {
        if (selectedCategoryFilter == null) meals
        else meals.filter { it.category == selectedCategoryFilter }
    }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Spacer(modifier = Modifier.height(4.dp))

            // Top Header Row (Apple Smart Home style title + live badge)
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 4.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "Nutrition & Macros",
                        color = TextPrimary,
                        fontSize = 22.sp,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = (-0.4).sp
                    )
                    Text(
                        text = "${eatenMeals.size} eaten • ${skippedMeals.size} skipped today",
                        color = TextSecondary,
                        fontSize = 12.sp
                    )
                }

                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    AppleLiveStatusBadge(
                        text = "${((totalCalories.toFloat() / DefaultNutritionData.DEFAULT_CALORIE_TARGET) * 100).toInt().coerceAtMost(100)}% Fuel",
                        dotColor = AccentToxic
                    )
                    Box(
                        modifier = Modifier
                            .size(34.dp)
                            .clip(CircleShape)
                            .background(Color(0xCC1A1C22))
                            .border(0.8.dp, Color.White.copy(alpha = 0.14f), CircleShape)
                            .clickable { protocolPrefs.resetMealsToDefault() },
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.Refresh,
                            contentDescription = "Reset Meals",
                            tint = TextSecondary,
                            modifier = Modifier.size(16.dp)
                        )
                    }
                }
            }
        }

        // 2x2 Apple Bento Metric Cards with Tick-Mark Ruler Bars
        item {
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    AppleBentoMetricCard(
                        icon = Icons.Default.Bolt,
                        title = "Energy Intake",
                        subtitle = "Target ${DefaultNutritionData.DEFAULT_CALORIE_TARGET} kcal",
                        currentValueText = "$totalCalories kcal",
                        progress = totalCalories.toFloat() / DefaultNutritionData.DEFAULT_CALORIE_TARGET,
                        accentColor = AccentFlame,
                        modifier = Modifier.weight(1f)
                    )
                    AppleBentoMetricCard(
                        icon = Icons.Default.FitnessCenter,
                        title = "Protein",
                        subtitle = "Target ${DefaultNutritionData.DEFAULT_PROTEIN_TARGET}g",
                        currentValueText = "${totalProtein}g",
                        progress = totalProtein.toFloat() / DefaultNutritionData.DEFAULT_PROTEIN_TARGET,
                        accentColor = AccentFrost,
                        modifier = Modifier.weight(1f)
                    )
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    AppleBentoMetricCard(
                        icon = Icons.Default.Grain,
                        title = "Carbohydrates",
                        subtitle = "Glycogen ${DefaultNutritionData.DEFAULT_CARBS_TARGET}g",
                        currentValueText = "${totalCarbs}g",
                        progress = totalCarbs.toFloat() / DefaultNutritionData.DEFAULT_CARBS_TARGET,
                        accentColor = AccentToxic,
                        modifier = Modifier.weight(1f)
                    )
                    AppleBentoMetricCard(
                        icon = Icons.Default.WaterDrop,
                        title = "Healthy Fats",
                        subtitle = "Hormonal ${DefaultNutritionData.DEFAULT_FATS_TARGET}g",
                        currentValueText = "${totalFats}g",
                        progress = totalFats.toFloat() / DefaultNutritionData.DEFAULT_FATS_TARGET,
                        accentColor = AccentIndigo,
                        modifier = Modifier.weight(1f)
                    )
                }
            }
        }

        // Apple "Rooms / + Add room" Style Meal Slot Control Container
        item {
            MealSlotControlContainer(
                selectedCategory = selectedCategoryFilter,
                onSelectCategory = { selectedCategoryFilter = it },
                skippedCount = skippedMeals.size,
                onAddFoodClick = {
                    dialogInitialCategory = selectedCategoryFilter ?: MealCategory.LUNCH
                    dialogReplacedItemName = null
                    showAddFoodDialog = true
                }
            )
        }

        // Meal Items List (with Eaten / Skip / Replace item actions)
        items(filteredMeals, key = { it.id }) { item ->
            AppleMealItemCard(
                item = item,
                onMarkEaten = {
                    val next = if (item.status == MealItemStatus.EATEN) MealItemStatus.PLANNED else MealItemStatus.EATEN
                    protocolPrefs.updateMealItemStatus(item.id, next)
                    AudioChimeHelper.vibrate(context, 45)
                },
                onMarkSkipped = {
                    val next = if (item.status == MealItemStatus.SKIPPED) MealItemStatus.PLANNED else MealItemStatus.SKIPPED
                    protocolPrefs.updateMealItemStatus(item.id, next)
                    AudioChimeHelper.vibrate(context, 45)
                },
                onReplaceSkippedItem = {
                    dialogInitialCategory = item.category
                    dialogReplacedItemName = item.name
                    showAddFoodDialog = true
                },
                onDelete = {
                    protocolPrefs.deleteFoodItem(item.id)
                }
            )
        }

        // Apple "Optimize Your Home for the Night" Inspired Gemini AI Nutrition & Recovery Card
        item {
            AppleGeminiOptimizeCard(
                skippedCount = skippedMeals.size,
                remainingCalories = (DefaultNutritionData.DEFAULT_CALORIE_TARGET - totalCalories).coerceAtLeast(0),
                remainingProtein = (DefaultNutritionData.DEFAULT_PROTEIN_TARGET - totalProtein).coerceAtLeast(0),
                coachStreamState = coachStreamState,
                onOptimizeClick = {
                    aiViewModel.streamProtocolOptimization(
                        workoutTitle = currentWorkoutTitle,
                        completedSets = completedSets,
                        waterMl = waterMl,
                        meals = meals
                    )
                }
            )
        }

        item {
            Spacer(modifier = Modifier.height(96.dp))
        }
    }

    if (showAddFoodDialog) {
        AddFoodItemDialog(
            initialCategory = dialogInitialCategory,
            replacedItemName = dialogReplacedItemName,
            aiViewModel = aiViewModel,
            onDismiss = {
                aiViewModel.resetFoodAnalysis()
                showAddFoodDialog = false
            },
            onAddFood = { name, category, kcal, p, c, f ->
                protocolPrefs.addFoodItem(
                    name = name,
                    category = category,
                    calories = kcal,
                    protein = p,
                    carbs = c,
                    fats = f,
                    markEatenImmediately = true
                )
                AudioChimeHelper.vibrate(context, 60)
                aiViewModel.resetFoodAnalysis()
                showAddFoodDialog = false
            }
        )
    }
}

/**
 * Replicates the "New scenario -> Rooms / Bathroom / + Add room" frosted glass container
 * from the top-center phone in the user's inspiration screenshot.
 */
@Composable
private fun MealSlotControlContainer(
    selectedCategory: MealCategory?,
    onSelectCategory: (MealCategory?) -> Unit,
    skippedCount: Int,
    onAddFoodClick: () -> Unit
) {
    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        // 1. Top Segmented Pill Container (All, Breakfast, Lunch, Pre, Post, Dinner)
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(26.dp))
                .background(Color(0xE6181A20))
                .border(1.dp, appleSpecularBorderBrush(), RoundedCornerShape(26.dp))
                .padding(6.dp)
        ) {
            LazyRow(
                horizontalArrangement = Arrangement.spacedBy(6.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                item {
                    AppleCategoryTabChip(
                        label = "All Meals",
                        sub = "Full Day",
                        selected = selectedCategory == null,
                        onClick = { onSelectCategory(null) }
                    )
                }
                items(MealCategory.entries) { category ->
                    AppleCategoryTabChip(
                        label = category.displayName,
                        sub = category.timeHint,
                        selected = selectedCategory == category,
                        onClick = { onSelectCategory(category) }
                    )
                }
            }
        }

        // 2. "Rooms -> [Skipped Filter] [+ Add item]" Glass Container
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(26.dp))
                .background(Color(0xE6181A20))
                .border(1.dp, appleSpecularBorderBrush(), RoundedCornerShape(26.dp))
                .padding(16.dp)
        ) {
            Column {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.Restaurant,
                            contentDescription = null,
                            tint = TextSecondary,
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = selectedCategory?.displayName ?: "Daily Meal Protocol",
                            color = TextPrimary,
                            fontSize = 15.sp,
                            fontWeight = FontWeight.SemiBold
                        )
                    }

                    if (skippedCount > 0) {
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(999.dp))
                                .background(AccentFlame.copy(alpha = 0.16f))
                                .border(0.8.dp, AccentFlame.copy(alpha = 0.4f), RoundedCornerShape(999.dp))
                                .padding(horizontal = 10.dp, vertical = 4.dp)
                        ) {
                            Text(
                                text = "$skippedCount Skipped",
                                color = AccentFlame,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                // Pill buttons row matching "[Bathroom] [+ Add room]" in the screenshot
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    // Add custom or replacement item button
                    Row(
                        modifier = Modifier
                            .weight(1f)
                            .height(46.dp)
                            .clip(RoundedCornerShape(999.dp))
                            .background(Color(0xFF282A32))
                            .border(
                                1.dp,
                                Color.White.copy(alpha = 0.18f),
                                RoundedCornerShape(999.dp)
                            )
                            .clickable { onAddFoodClick() }
                            .testTag("add_food_item_button")
                            .padding(horizontal = 16.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.Add,
                            contentDescription = "Add Item",
                            tint = TextPrimary,
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "Add meal item / AI Scan",
                            color = TextPrimary,
                            fontSize = 13.sp,
                            fontWeight = FontWeight.SemiBold
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun AppleCategoryTabChip(
    label: String,
    sub: String,
    selected: Boolean,
    onClick: () -> Unit
) {
    val bgColor by animateColorAsState(
        targetValue = if (selected) Color(0xFF2E313A) else Color.Transparent,
        animationSpec = spring(),
        label = "meal_cat_bg"
    )
    Box(
        modifier = Modifier
            .clip(RoundedCornerShape(20.dp))
            .background(bgColor)
            .then(
                if (selected) {
                    Modifier.border(0.8.dp, Color.White.copy(alpha = 0.22f), RoundedCornerShape(20.dp))
                } else {
                    Modifier
                }
            )
            .clickable { onClick() }
            .padding(horizontal = 16.dp, vertical = 10.dp),
        contentAlignment = Alignment.Center
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text(
                text = label,
                color = if (selected) TextPrimary else TextSecondary,
                fontSize = 12.sp,
                fontWeight = if (selected) FontWeight.Bold else FontWeight.Medium
            )
            Text(
                text = sub,
                color = if (selected) AccentFlame else TextTertiary,
                fontSize = 9.sp,
                fontFamily = FontFamily.Monospace
            )
        }
    }
}

@Composable
private fun AppleMealItemCard(
    item: FoodItem,
    onMarkEaten: () -> Unit,
    onMarkSkipped: () -> Unit,
    onReplaceSkippedItem: () -> Unit,
    onDelete: () -> Unit
) {
    val isEaten = item.status == MealItemStatus.EATEN
    val isSkipped = item.status == MealItemStatus.SKIPPED

    val borderBrush = when {
        isEaten -> Brush.linearGradient(
            listOf(AccentToxic.copy(alpha = 0.55f), AccentToxic.copy(alpha = 0.15f))
        )
        isSkipped -> Brush.linearGradient(
            listOf(AccentFlame.copy(alpha = 0.55f), AccentRed.copy(alpha = 0.20f))
        )
        else -> appleSpecularBorderBrush()
    }

    Box(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(24.dp))
            .background(
                when {
                    isEaten -> Color(0xE614201A)
                    isSkipped -> Color(0xE6221616)
                    else -> Color(0xE6181A20)
                }
            )
            .border(1.dp, borderBrush, RoundedCornerShape(24.dp))
            .padding(16.dp)
    ) {
        Column {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.Top
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(6.dp))
                                .background(Color.White.copy(alpha = 0.08f))
                                .padding(horizontal = 7.dp, vertical = 2.dp)
                        ) {
                            Text(
                                text = item.category.displayName.uppercase(),
                                color = AccentFrost,
                                fontSize = 9.sp,
                                fontFamily = FontFamily.Monospace,
                                fontWeight = FontWeight.Bold
                            )
                        }

                        if (isSkipped) {
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(6.dp))
                                    .background(AccentFlame.copy(alpha = 0.2f))
                                    .padding(horizontal = 7.dp, vertical = 2.dp)
                            ) {
                                Text(
                                    text = "SKIPPED • 0 KCAL",
                                    color = AccentFlame,
                                    fontSize = 9.sp,
                                    fontFamily = FontFamily.Monospace,
                                    fontWeight = FontWeight.ExtraBold
                                )
                            }
                        } else if (isEaten) {
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(6.dp))
                                    .background(AccentToxic.copy(alpha = 0.2f))
                                    .padding(horizontal = 7.dp, vertical = 2.dp)
                            ) {
                                Text(
                                    text = "LOGGED",
                                    color = AccentToxic,
                                    fontSize = 9.sp,
                                    fontFamily = FontFamily.Monospace,
                                    fontWeight = FontWeight.ExtraBold
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(6.dp))

                    Text(
                        text = item.name,
                        color = if (isSkipped) TextSecondary else TextPrimary,
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Bold,
                        textDecoration = if (isSkipped) TextDecoration.LineThrough else TextDecoration.None
                    )

                    Spacer(modifier = Modifier.height(4.dp))

                    Text(
                        text = "${item.calories} kcal  •  ${item.proteinGrams}g Protein  •  ${item.carbsGrams}g C  •  ${item.fatsGrams}g F",
                        color = if (isSkipped) TextTertiary else AccentFlame,
                        fontSize = 11.sp,
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.SemiBold
                    )
                }

                IconButton(
                    onClick = onDelete,
                    modifier = Modifier.size(28.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.DeleteOutline,
                        contentDescription = "Remove item",
                        tint = TextTertiary,
                        modifier = Modifier.size(17.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Action Controls: [Eaten] [Skip] and if Skipped -> [+ Add Replacement]
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Eaten toggle pill
                Row(
                    modifier = Modifier
                        .weight(1f)
                        .height(38.dp)
                        .clip(RoundedCornerShape(999.dp))
                        .background(
                            if (isEaten) AccentToxic else Color.White.copy(alpha = 0.06f)
                        )
                        .border(
                            1.dp,
                            if (isEaten) AccentToxic else Color.White.copy(alpha = 0.14f),
                            RoundedCornerShape(999.dp)
                        )
                        .clickable { onMarkEaten() },
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.Check,
                        contentDescription = null,
                        tint = if (isEaten) Color.Black else TextSecondary,
                        modifier = Modifier.size(15.dp)
                    )
                    Spacer(modifier = Modifier.width(5.dp))
                    Text(
                        text = if (isEaten) "Eaten" else "Mark Eaten",
                        color = if (isEaten) Color.Black else TextPrimary,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold
                    )
                }

                // Skip toggle pill
                Row(
                    modifier = Modifier
                        .weight(1f)
                        .height(38.dp)
                        .clip(RoundedCornerShape(999.dp))
                        .background(
                            if (isSkipped) AccentFlame.copy(alpha = 0.25f) else Color.White.copy(alpha = 0.06f)
                        )
                        .border(
                            1.dp,
                            if (isSkipped) AccentFlame else Color.White.copy(alpha = 0.14f),
                            RoundedCornerShape(999.dp)
                        )
                        .clickable { onMarkSkipped() },
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.RemoveCircleOutline,
                        contentDescription = null,
                        tint = if (isSkipped) AccentFlame else TextSecondary,
                        modifier = Modifier.size(15.dp)
                    )
                    Spacer(modifier = Modifier.width(5.dp))
                    Text(
                        text = if (isSkipped) "Skipped" else "Skip Item",
                        color = if (isSkipped) AccentFlame else TextSecondary,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }

            // If item was skipped, show instant "+ Add Replacement Item" prompt bar
            AnimatedVisibility(visible = isSkipped) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(top = 10.dp)
                        .clip(RoundedCornerShape(14.dp))
                        .background(AccentFlame.copy(alpha = 0.14f))
                        .border(1.dp, AccentFlame.copy(alpha = 0.35f), RoundedCornerShape(14.dp))
                        .clickable { onReplaceSkippedItem() }
                        .padding(horizontal = 12.dp, vertical = 10.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.weight(1f)
                    ) {
                        Icon(
                            imageVector = Icons.Default.SwapHoriz,
                            contentDescription = null,
                            tint = AccentFlame,
                            modifier = Modifier.size(17.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "Skipped this item? Add what you ate instead",
                            color = TextPrimary,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.SemiBold
                        )
                    }
                    Text(
                        text = "+ ADD",
                        color = AccentFlame,
                        fontSize = 11.sp,
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.ExtraBold
                    )
                }
            }
        }
    }
}

/**
 * Replicates the right-hand screen in the inspiration image ("Optimize Your Home for the Night")
 * with a starlight dot-matrix canvas, crescent/sparkle emblem, nested "Suggested setup:" container,
 * and the vibrant orange action pill button powered by Gemini 3.8 Flash.
 */
@Composable
private fun AppleGeminiOptimizeCard(
    skippedCount: Int,
    remainingCalories: Int,
    remainingProtein: Int,
    coachStreamState: CoachStreamUiState,
    onOptimizeClick: () -> Unit
) {
    val starPoints = remember {
        val r = Random(99)
        List(48) {
            Triple(r.nextFloat(), r.nextFloat() * 0.45f, r.nextFloat() * 0.45f + 0.15f)
        }
    }

    Box(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(32.dp))
            .background(Color(0xF215171C))
            .border(1.dp, appleSpecularBorderBrush(), RoundedCornerShape(32.dp))
    ) {
        // Starlight / dot-matrix ambient top glow
        Canvas(modifier = Modifier.matchParentSize()) {
            drawCircle(
                brush = Brush.radialGradient(
                    colors = listOf(
                        Color.White.copy(alpha = 0.09f),
                        AccentFlame.copy(alpha = 0.05f),
                        Color.Transparent
                    ),
                    center = Offset(size.width * 0.5f, 80.dp.toPx()),
                    radius = size.width * 0.65f
                ),
                center = Offset(size.width * 0.5f, 80.dp.toPx()),
                radius = size.width * 0.65f
            )
            starPoints.forEach { (rx, ry, alpha) ->
                drawCircle(
                    color = Color.White.copy(alpha = alpha),
                    radius = 1.3.dp.toPx(),
                    center = Offset(rx * size.width, ry * size.height)
                )
            }
        }

        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(22.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // Top Glowing Crescent / AI Emblem
            Box(
                modifier = Modifier
                    .size(58.dp)
                    .clip(CircleShape)
                    .background(Color.White.copy(alpha = 0.06f))
                    .border(1.dp, Color.White.copy(alpha = 0.16f), CircleShape),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Default.NightlightRound,
                    contentDescription = null,
                    tint = Color.White,
                    modifier = Modifier.size(30.dp)
                )
            }

            Spacer(modifier = Modifier.height(16.dp))

            Text(
                text = "Optimize Your Protocol\nwith Gemini AI",
                color = TextPrimary,
                fontSize = 22.sp,
                fontWeight = FontWeight.Bold,
                textAlign = TextAlign.Center,
                lineHeight = 27.sp
            )

            Spacer(modifier = Modifier.height(8.dp))

            Text(
                text = "Gemini 3.8 Flash analyzes your skipped items ($skippedCount skipped), remaining macros ($remainingCalories kcal & ${remainingProtein}g protein left), and today's workout to rebalance your Winter Arc meals.",
                color = TextSecondary,
                fontSize = 12.sp,
                textAlign = TextAlign.Center,
                lineHeight = 17.sp
            )

            Spacer(modifier = Modifier.height(18.dp))

            // Nested "Suggested setup:" Dark Container matching screenshot
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(22.dp))
                    .background(Color(0xCC1E2027))
                    .border(0.8.dp, Color.White.copy(alpha = 0.08f), RoundedCornerShape(22.dp))
                    .padding(16.dp)
            ) {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text(
                        text = "Live protocol snapshot:",
                        color = TextPrimary,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.SemiBold
                    )

                    AppleSuggestedSetupRow(
                        icon = Icons.Default.SwapHoriz,
                        text = if (skippedCount > 0) {
                            "$skippedCount meal item(s) skipped — AI will suggest high-protein swaps"
                        } else {
                            "Zero skipped meals so far — keep hitting clean whole-food macros"
                        }
                    )
                    AppleSuggestedSetupRow(
                        icon = Icons.Default.LocalFireDepartment,
                        text = "$remainingCalories kcal and ${remainingProtein}g protein remaining for today's target"
                    )
                    AppleSuggestedSetupRow(
                        icon = Icons.Default.AutoAwesome,
                        text = "Instant Hinglish + English meal & recovery adjustments"
                    )

                    // Streamed Gemini Output Display
                    when (coachStreamState) {
                        is CoachStreamUiState.Idle -> {}
                        is CoachStreamUiState.Loading -> {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(top = 8.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.Center
                            ) {
                                CircularProgressIndicator(
                                    color = AccentFlame,
                                    modifier = Modifier.size(20.dp),
                                    strokeWidth = 2.dp
                                )
                                Spacer(modifier = Modifier.width(10.dp))
                                Text(
                                    text = "Gemini 3.8 Flash is optimizing your meals...",
                                    color = AccentFrost,
                                    fontSize = 12.sp,
                                    fontFamily = FontFamily.Monospace
                                )
                            }
                        }
                        is CoachStreamUiState.Streaming -> {
                            AiCoachOutputBox(text = coachStreamState.text, isStreaming = true)
                        }
                        is CoachStreamUiState.Success -> {
                            AiCoachOutputBox(text = coachStreamState.text, isStreaming = false)
                        }
                        is CoachStreamUiState.Error -> {
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(14.dp))
                                    .background(AccentRed.copy(alpha = 0.15f))
                                    .border(1.dp, AccentRed.copy(alpha = 0.4f), RoundedCornerShape(14.dp))
                                    .padding(12.dp)
                            ) {
                                Text(
                                    text = coachStreamState.message,
                                    color = Color(0xFFFCA5A5),
                                    fontSize = 12.sp
                                )
                            }
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(18.dp))

            // Signature Orange Pill CTA Button
            AppleOrangeActionPillButton(
                text = "Optimize meal plan with AI",
                icon = Icons.Default.AutoAwesome,
                onClick = onOptimizeClick,
                enabled = coachStreamState !is CoachStreamUiState.Loading
            )
        }
    }
}

@Composable
private fun AppleSuggestedSetupRow(
    icon: ImageVector,
    text: String
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(14.dp))
            .background(Color(0xFF282B34))
            .border(0.6.dp, Color.White.copy(alpha = 0.08f), RoundedCornerShape(14.dp))
            .padding(horizontal = 12.dp, vertical = 11.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(
            imageVector = icon,
            contentDescription = null,
            tint = TextSecondary,
            modifier = Modifier.size(18.dp)
        )
        Spacer(modifier = Modifier.width(12.dp))
        Text(
            text = text,
            color = TextSecondary,
            fontSize = 12.sp,
            lineHeight = 16.sp
        )
    }
}

@Composable
private fun AiCoachOutputBox(
    text: String,
    isStreaming: Boolean
) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .padding(top = 6.dp)
            .clip(RoundedCornerShape(16.dp))
            .background(Color(0xFF14161C))
            .border(1.dp, AccentFlame.copy(alpha = 0.45f), RoundedCornerShape(16.dp))
            .padding(14.dp)
    ) {
        Column {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
                modifier = Modifier.fillMaxWidth()
            ) {
                Text(
                    text = if (isStreaming) "✨ GEMINI LIVE STREAM..." else "✨ GEMINI PROTOCOL PLAN",
                    color = AccentFlame,
                    fontSize = 10.sp,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.ExtraBold
                )
            }
            Spacer(modifier = Modifier.height(6.dp))
            Text(
                text = text,
                color = TextPrimary,
                fontSize = 12.sp,
                lineHeight = 18.sp
            )
        }
    }
}

@Composable
private fun AddFoodItemDialog(
    initialCategory: MealCategory,
    replacedItemName: String?,
    aiViewModel: WinterArcAiViewModel,
    onDismiss: () -> Unit,
    onAddFood: (name: String, category: MealCategory, kcal: Int, p: Int, c: Int, f: Int) -> Unit
) {
    var selectedCategory by remember { mutableStateOf(initialCategory) }
    var aiPromptInput by remember { mutableStateOf("") }
    var foodName by remember { mutableStateOf("") }
    var caloriesText by remember { mutableStateOf("") }
    var proteinText by remember { mutableStateOf("") }
    var carbsText by remember { mutableStateOf("") }
    var fatsText by remember { mutableStateOf("") }
    var coachVerdict by remember { mutableStateOf<String?>(null) }

    val foodAnalysisState by aiViewModel.foodAnalysisState.collectAsState()

    // When Gemini structured output succeeds, auto-populate the fields
    LaunchedEffect(foodAnalysisState) {
        if (foodAnalysisState is FoodAnalysisUiState.Success) {
            val analyzed = (foodAnalysisState as FoodAnalysisUiState.Success).analyzedFood
            foodName = analyzed.foodName
            caloriesText = analyzed.calories.toString()
            proteinText = analyzed.proteinGrams.toString()
            carbsText = analyzed.carbsGrams.toString()
            fatsText = analyzed.fatsGrams.toString()
            coachVerdict = analyzed.coachVerdict
        }
    }

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(
            dismissOnBackPress = true,
            dismissOnClickOutside = true,
            usePlatformDefaultWidth = false
        )
    ) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(Color.Black.copy(alpha = 0.85f))
                .clickable { onDismiss() }
                .padding(16.dp),
            contentAlignment = Alignment.Center
        ) {
            Surface(
                modifier = Modifier
                    .fillMaxWidth(0.96f)
                    .clip(RoundedCornerShape(28.dp))
                    .border(1.dp, appleSpecularBorderBrush(), RoundedCornerShape(28.dp))
                    .clickable(enabled = false) {},
                color = GlassSurfaceOverlay
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .verticalScroll(rememberScrollState())
                        .padding(20.dp)
                ) {
                    // Header
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = if (replacedItemName != null) "Replace Skipped Item" else "Add Meal Item",
                                color = TextPrimary,
                                fontSize = 18.sp,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = if (replacedItemName != null) {
                                    "Replacing: $replacedItemName"
                                } else {
                                    "Log custom food or estimate macros with Gemini AI"
                                },
                                color = AccentFrost,
                                fontSize = 11.sp,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                        }
                        IconButton(
                            onClick = onDismiss,
                            modifier = Modifier
                                .size(32.dp)
                                .clip(CircleShape)
                                .background(Color.White.copy(alpha = 0.08f))
                        ) {
                            Icon(
                                imageVector = Icons.Default.Close,
                                contentDescription = "Close",
                                tint = Color.White,
                                modifier = Modifier.size(16.dp)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    // Meal Category Selector
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        items(MealCategory.entries) { cat ->
                            val isSel = cat == selectedCategory
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(999.dp))
                                    .background(if (isSel) AccentFlame else Color.White.copy(alpha = 0.07f))
                                    .clickable { selectedCategory = cat }
                                    .padding(horizontal = 12.dp, vertical = 7.dp)
                            ) {
                                Text(
                                    text = cat.displayName,
                                    color = if (isSel) Color.Black else TextSecondary,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    // ✨ Gemini AI Smart Estimator Box
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(18.dp))
                            .background(Color(0xFF1A1D26))
                            .border(1.dp, AccentFlame.copy(alpha = 0.35f), RoundedCornerShape(18.dp))
                            .padding(14.dp)
                    ) {
                        Column {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(
                                    imageVector = Icons.Default.AutoAwesome,
                                    contentDescription = null,
                                    tint = AccentFlame,
                                    modifier = Modifier.size(16.dp)
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = "GEMINI AI MACRO ESTIMATOR",
                                    color = AccentFlame,
                                    fontSize = 11.sp,
                                    fontFamily = FontFamily.Monospace,
                                    fontWeight = FontWeight.ExtraBold
                                )
                            }
                            Spacer(modifier = Modifier.height(6.dp))
                            OutlinedTextField(
                                value = aiPromptInput,
                                onValueChange = { aiPromptInput = it },
                                placeholder = {
                                    Text(
                                        text = "e.g., 2 paneer paratha with 1 bowl dahi",
                                        color = TextTertiary,
                                        fontSize = 12.sp
                                    )
                                },
                                modifier = Modifier.fillMaxWidth(),
                                singleLine = true,
                                colors = OutlinedTextFieldDefaults.colors(
                                    focusedTextColor = TextPrimary,
                                    unfocusedTextColor = TextPrimary,
                                    focusedBorderColor = AccentFlame,
                                    unfocusedBorderColor = Color.White.copy(alpha = 0.14f)
                                )
                            )
                            Spacer(modifier = Modifier.height(8.dp))

                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(12.dp))
                                    .background(AccentFlame.copy(alpha = 0.22f))
                                    .border(1.dp, AccentFlame, RoundedCornerShape(12.dp))
                                    .clickable(enabled = foodAnalysisState !is FoodAnalysisUiState.Loading) {
                                        aiViewModel.analyzeFoodDescription(aiPromptInput)
                                    }
                                    .padding(vertical = 10.dp),
                                horizontalArrangement = Arrangement.Center,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                if (foodAnalysisState is FoodAnalysisUiState.Loading) {
                                    CircularProgressIndicator(
                                        color = AccentFlame,
                                        modifier = Modifier.size(16.dp),
                                        strokeWidth = 2.dp
                                    )
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text(
                                        text = "Calculating Macros...",
                                        color = TextPrimary,
                                        fontSize = 12.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                } else {
                                    Icon(
                                        imageVector = Icons.Default.AutoAwesome,
                                        contentDescription = null,
                                        tint = AccentFlame,
                                        modifier = Modifier.size(16.dp)
                                    )
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text(
                                        text = "Auto-Fill Macros with Gemini AI",
                                        color = TextPrimary,
                                        fontSize = 12.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                            }

                            if (foodAnalysisState is FoodAnalysisUiState.Error) {
                                Spacer(modifier = Modifier.height(6.dp))
                                Text(
                                    text = (foodAnalysisState as FoodAnalysisUiState.Error).message,
                                    color = Color(0xFFFCA5A5),
                                    fontSize = 11.sp
                                )
                            }

                            coachVerdict?.let { verdict ->
                                Spacer(modifier = Modifier.height(6.dp))
                                Text(
                                    text = "💡 $verdict",
                                    color = AccentToxic,
                                    fontSize = 11.sp,
                                    lineHeight = 15.sp
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    // Quick Presets Row
                    Text(
                        text = "QUICK INDIAN & GYM PRESETS (TAP TO FILL):",
                        color = TextTertiary,
                        fontSize = 10.sp,
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        items(DefaultNutritionData.quickPresets) { preset ->
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(12.dp))
                                    .background(Color.White.copy(alpha = 0.06f))
                                    .border(0.8.dp, Color.White.copy(alpha = 0.12f), RoundedCornerShape(12.dp))
                                    .clickable {
                                        foodName = preset.name
                                        caloriesText = preset.calories.toString()
                                        proteinText = preset.protein.toString()
                                        carbsText = preset.carbs.toString()
                                        fatsText = preset.fats.toString()
                                    }
                                    .padding(horizontal = 10.dp, vertical = 8.dp)
                            ) {
                                Column {
                                    Text(
                                        text = preset.name,
                                        color = TextPrimary,
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.SemiBold
                                    )
                                    Text(
                                        text = "${preset.calories} kcal • ${preset.protein}g P",
                                        color = AccentFrost,
                                        fontSize = 10.sp,
                                        fontFamily = FontFamily.Monospace
                                    )
                                }
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    // Manual / Auto-Filled Fields
                    OutlinedTextField(
                        value = foodName,
                        onValueChange = { foodName = it },
                        label = { Text("Food / Meal Item Name", fontSize = 12.sp) },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true,
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedTextColor = TextPrimary,
                            unfocusedTextColor = TextPrimary,
                            focusedBorderColor = AccentFrost,
                            unfocusedBorderColor = Color.White.copy(alpha = 0.14f)
                        )
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        OutlinedTextField(
                            value = caloriesText,
                            onValueChange = { caloriesText = it.filter { ch -> ch.isDigit() } },
                            label = { Text("Calories (kcal)", fontSize = 11.sp) },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            modifier = Modifier.weight(1f),
                            singleLine = true,
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedTextColor = TextPrimary,
                                unfocusedTextColor = TextPrimary,
                                focusedBorderColor = AccentFlame,
                                unfocusedBorderColor = Color.White.copy(alpha = 0.14f)
                            )
                        )
                        OutlinedTextField(
                            value = proteinText,
                            onValueChange = { proteinText = it.filter { ch -> ch.isDigit() } },
                            label = { Text("Protein (g)", fontSize = 11.sp) },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            modifier = Modifier.weight(1f),
                            singleLine = true,
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedTextColor = TextPrimary,
                                unfocusedTextColor = TextPrimary,
                                focusedBorderColor = AccentFrost,
                                unfocusedBorderColor = Color.White.copy(alpha = 0.14f)
                            )
                        )
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        OutlinedTextField(
                            value = carbsText,
                            onValueChange = { carbsText = it.filter { ch -> ch.isDigit() } },
                            label = { Text("Carbs (g)", fontSize = 11.sp) },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            modifier = Modifier.weight(1f),
                            singleLine = true,
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedTextColor = TextPrimary,
                                unfocusedTextColor = TextPrimary,
                                focusedBorderColor = AccentToxic,
                                unfocusedBorderColor = Color.White.copy(alpha = 0.14f)
                            )
                        )
                        OutlinedTextField(
                            value = fatsText,
                            onValueChange = { fatsText = it.filter { ch -> ch.isDigit() } },
                            label = { Text("Fats (g)", fontSize = 11.sp) },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            modifier = Modifier.weight(1f),
                            singleLine = true,
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedTextColor = TextPrimary,
                                unfocusedTextColor = TextPrimary,
                                focusedBorderColor = AccentIndigo,
                                unfocusedBorderColor = Color.White.copy(alpha = 0.14f)
                            )
                        )
                    }

                    Spacer(modifier = Modifier.height(18.dp))

                    AppleOrangeActionPillButton(
                        text = "Add to ${selectedCategory.displayName}",
                        icon = Icons.Default.Add,
                        enabled = foodName.isNotBlank(),
                        onClick = {
                            onAddFood(
                                foodName.ifBlank { "Custom Meal" },
                                selectedCategory,
                                caloriesText.toIntOrNull() ?: 200,
                                proteinText.toIntOrNull() ?: 12,
                                carbsText.toIntOrNull() ?: 20,
                                fatsText.toIntOrNull() ?: 6
                            )
                        }
                    )
                }
            }
        }
    }
}
