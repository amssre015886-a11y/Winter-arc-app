package com.example.ui.tabs

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.ExpandLess
import androidx.compose.material.icons.filled.ExpandMore
import androidx.compose.material.icons.filled.FitnessCenter
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.ProtocolPreferences
import com.example.model.DayProtocol
import com.example.model.DefaultNutritionData
import com.example.model.Exercise
import com.example.model.MealItemStatus
import com.example.model.WorkoutRepository
import com.example.ui.components.AppleBentoMetricCard
import com.example.ui.components.AppleLiveStatusBadge
import com.example.ui.components.AudioChimeHelper
import com.example.ui.components.appleSpecularBorderBrush
import com.example.ui.theme.AccentFlame
import com.example.ui.theme.AccentFrost
import com.example.ui.theme.AccentRed
import com.example.ui.theme.AccentToxic
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.theme.TextTertiary

@Composable
fun TodayGoalTab(
    protocolPrefs: ProtocolPreferences,
    onWatchVideo: (Exercise) -> Unit,
    onOpenCaloriesTab: () -> Unit = {},
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    var selectedDayIndex by remember { mutableStateOf(0) } // 0 = Sunday
    val currentProtocol = WorkoutRepository.getProtocolForDayOfWeek(selectedDayIndex)

    var warmUpExpanded by remember { mutableStateOf(true) }
    val completedSetsCount by protocolPrefs.completedSetsCountFlow.collectAsState()
    val meals by protocolPrefs.mealsFlow.collectAsState()

    val eatenCalories = remember(meals) {
        meals.filter { it.status == MealItemStatus.EATEN }.sumOf { it.calories }
    }

    // Calculate total sets for this protocol
    val totalSetsInProtocol = remember(currentProtocol) {
        currentProtocol.exercises.sumOf { it.sets }
    }

    // Key to trigger recomposition of individual pills
    var setToggleTick by remember { mutableStateOf(0) }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Spacer(modifier = Modifier.height(4.dp))

            // Apple Segmented Weekday Container (Sunday - Saturday)
            DaySelectorBar(
                selectedDayIndex = selectedDayIndex,
                onSelectDay = { selectedDayIndex = it }
            )
        }

        // Hero Banner (Apple Dark Glass style)
        item {
            HeroBanner(
                protocol = currentProtocol,
                completedSets = completedSetsCount,
                totalSets = totalSetsInProtocol,
                onResetAllSets = {
                    protocolPrefs.resetAllSetsToday()
                    setToggleTick++
                }
            )
        }

        // Apple Bento Cards with Tick-Mark Ruler Bars (Sets Progress & Daily Fuel)
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                AppleBentoMetricCard(
                    icon = Icons.Default.FitnessCenter,
                    title = "Session Volume",
                    subtitle = "${currentProtocol.exercises.size} movements",
                    currentValueText = "$completedSetsCount/$totalSetsInProtocol Sets",
                    progress = if (totalSetsInProtocol > 0) completedSetsCount.toFloat() / totalSetsInProtocol else 0f,
                    accentColor = AccentFlame,
                    modifier = Modifier.weight(1f)
                )
                AppleBentoMetricCard(
                    icon = Icons.Default.Bolt,
                    title = "Calorie Fuel",
                    subtitle = "Tap to log meals",
                    currentValueText = "$eatenCalories kcal",
                    progress = eatenCalories.toFloat() / DefaultNutritionData.DEFAULT_CALORIE_TARGET,
                    accentColor = AccentFrost,
                    onClick = onOpenCaloriesTab,
                    modifier = Modifier.weight(1f)
                )
            }
        }

        // 5-Min Warmup Card
        item {
            WarmupCard(
                protocol = currentProtocol,
                expanded = warmUpExpanded,
                onToggleExpand = { warmUpExpanded = !warmUpExpanded }
            )
        }

        // Section Title: Exercises
        item {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 4.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Core Protocol Exercises",
                    color = TextPrimary,
                    fontSize = 17.sp,
                    fontWeight = FontWeight.Bold
                )
                AppleLiveStatusBadge(
                    text = "${currentProtocol.exercises.size} Active",
                    dotColor = AccentFlame
                )
            }
        }

        // Exercise Cards
        items(currentProtocol.exercises, key = { it.id }) { exercise ->
            ExerciseCard(
                exercise = exercise,
                protocolPrefs = protocolPrefs,
                setToggleTick = setToggleTick,
                onToggleSet = { setIndex ->
                    protocolPrefs.toggleSetCompleted(exercise.id, setIndex)
                    AudioChimeHelper.vibrate(context, 50)
                    setToggleTick++
                },
                onWatchVideo = { onWatchVideo(exercise) }
            )
        }

        item {
            Spacer(modifier = Modifier.height(94.dp))
        }
    }
}

@Composable
fun DaySelectorBar(
    selectedDayIndex: Int,
    onSelectDay: (Int) -> Unit
) {
    val days = listOf("SUN", "MON", "TUE", "WED", "THU", "FRI", "SAT")
    val tags = listOf("Push", "Pull", "Legs", "Core", "HIIT", "Upper", "Deadlift")

    Box(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(26.dp))
            .background(Color(0xE6181A20))
            .border(1.dp, appleSpecularBorderBrush(), RoundedCornerShape(26.dp))
            .padding(6.dp)
    ) {
        LazyRow(
            horizontalArrangement = Arrangement.spacedBy(6.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            items(days.indices.toList()) { index ->
                val isSelected = index == selectedDayIndex
                val bgColor by animateColorAsState(
                    targetValue = if (isSelected) Color(0xFF2E313A) else Color.Transparent,
                    animationSpec = spring(),
                    label = "day_bg"
                )

                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(20.dp))
                        .background(bgColor)
                        .then(
                            if (isSelected) {
                                Modifier.border(
                                    0.8.dp,
                                    Color.White.copy(alpha = 0.22f),
                                    RoundedCornerShape(20.dp)
                                )
                            } else {
                                Modifier
                            }
                        )
                        .clickable { onSelectDay(index) }
                        .padding(horizontal = 14.dp, vertical = 9.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(
                            text = days[index],
                            color = if (isSelected) TextPrimary else TextSecondary,
                            fontSize = 12.sp,
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.ExtraBold
                        )
                        Text(
                            text = tags[index],
                            color = if (isSelected) AccentFlame else TextTertiary,
                            fontSize = 9.sp,
                            fontWeight = FontWeight.SemiBold
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun HeroBanner(
    protocol: DayProtocol,
    completedSets: Int,
    totalSets: Int,
    onResetAllSets: () -> Unit
) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(28.dp))
            .background(
                Brush.linearGradient(
                    listOf(
                        Color(0xFF211B19),
                        Color(0xFF171920),
                        Color(0xFF13151B)
                    )
                )
            )
            .border(1.dp, appleSpecularBorderBrush(), RoundedCornerShape(28.dp))
            .padding(20.dp)
    ) {
        Column {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                AppleLiveStatusBadge(
                    text = "${protocol.tag} • ${protocol.targetDuration}",
                    dotColor = AccentFlame
                )

                Box(
                    modifier = Modifier
                        .size(32.dp)
                        .clip(CircleShape)
                        .background(Color.White.copy(alpha = 0.06f))
                        .border(0.8.dp, Color.White.copy(alpha = 0.12f), CircleShape)
                        .clickable { onResetAllSets() },
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.Refresh,
                        contentDescription = "Reset Sets",
                        tint = TextSecondary,
                        modifier = Modifier.size(15.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            Text(
                text = protocol.title,
                color = TextPrimary,
                fontSize = 23.sp,
                fontWeight = FontWeight.Bold,
                letterSpacing = (-0.5).sp
            )

            Spacer(modifier = Modifier.height(4.dp))

            Text(
                text = protocol.subtitle,
                color = TextSecondary,
                fontSize = 13.sp,
                lineHeight = 18.sp
            )

            Spacer(modifier = Modifier.height(16.dp))

            // Rings Grid
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                RingChip(
                    value = "$completedSets/$totalSets",
                    label = "Sets Done",
                    color = AccentFlame,
                    modifier = Modifier.weight(1f)
                )
                RingChip(
                    value = protocol.targetDuration,
                    label = "Target Time",
                    color = AccentFrost,
                    modifier = Modifier.weight(1f)
                )
                RingChip(
                    value = protocol.energyLevel,
                    label = "Energy",
                    color = AccentToxic,
                    modifier = Modifier.weight(1f)
                )
            }
        }
    }
}

@Composable
fun RingChip(
    value: String,
    label: String,
    color: Color,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .clip(RoundedCornerShape(18.dp))
            .background(Color.White.copy(alpha = 0.05f))
            .border(0.8.dp, Color.White.copy(alpha = 0.10f), RoundedCornerShape(18.dp))
            .padding(vertical = 12.dp, horizontal = 8.dp),
        contentAlignment = Alignment.Center
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                text = value,
                color = color,
                fontSize = 16.sp,
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.ExtraBold
            )
            Spacer(modifier = Modifier.height(2.dp))
            Text(
                text = label,
                color = TextTertiary,
                fontSize = 10.sp,
                fontWeight = FontWeight.SemiBold
            )
        }
    }
}

@Composable
fun WarmupCard(
    protocol: DayProtocol,
    expanded: Boolean,
    onToggleExpand: () -> Unit
) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(24.dp))
            .background(Color(0xE6181A20))
            .border(1.dp, appleSpecularBorderBrush(), RoundedCornerShape(24.dp))
            .padding(18.dp)
    ) {
        Column {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { onToggleExpand() },
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = "🔥 5-Minute Warm-Up (Mandatory)",
                        color = TextPrimary,
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(8.dp))
                            .background(AccentFlame.copy(alpha = 0.16f))
                            .padding(horizontal = 8.dp, vertical = 3.dp)
                    ) {
                        Text(
                            text = "PRE-WORKOUT",
                            color = AccentFlame,
                            fontSize = 9.sp,
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.Bold
                        )
                    }
                    Spacer(modifier = Modifier.width(6.dp))
                    Icon(
                        imageVector = if (expanded) Icons.Default.ExpandLess else Icons.Default.ExpandMore,
                        contentDescription = null,
                        tint = TextTertiary
                    )
                }
            }

            AnimatedVisibility(visible = expanded) {
                Column(modifier = Modifier.padding(top = 12.dp)) {
                    Text(
                        text = "Thande sharir par seedha weight na uthayein. Har session se pehle ye movements poori karein:",
                        color = TextSecondary,
                        fontSize = 12.sp,
                        lineHeight = 16.sp
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    protocol.warmups.forEachIndexed { i, warmup ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 4.dp)
                                .clip(RoundedCornerShape(12.dp))
                                .background(Color.White.copy(alpha = 0.04f))
                                .padding(horizontal = 12.dp, vertical = 8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "0${i + 1}",
                                color = AccentFlame,
                                fontSize = 11.sp,
                                fontFamily = FontFamily.Monospace,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.width(26.dp)
                            )
                            Column {
                                Text(
                                    text = warmup.title,
                                    color = TextPrimary,
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.SemiBold
                                )
                                Text(
                                    text = warmup.detail,
                                    color = TextTertiary,
                                    fontSize = 11.sp,
                                    fontFamily = FontFamily.Monospace
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun ExerciseCard(
    exercise: Exercise,
    protocolPrefs: ProtocolPreferences,
    setToggleTick: Int,
    onToggleSet: (Int) -> Unit,
    onWatchVideo: () -> Unit
) {
    val allCompleted = remember(setToggleTick) {
        (0 until exercise.sets).all { protocolPrefs.isSetCompleted(exercise.id, it) }
    }

    val borderBrush = if (allCompleted) {
        Brush.linearGradient(listOf(AccentToxic.copy(alpha = 0.6f), AccentToxic.copy(alpha = 0.15f)))
    } else {
        appleSpecularBorderBrush()
    }

    Box(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(24.dp))
            .background(if (allCompleted) Color(0xE614201A) else Color(0xE6181A20))
            .border(1.dp, borderBrush, RoundedCornerShape(24.dp))
            .padding(18.dp)
    ) {
        Column {
            // Exercise Header
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.Top
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = exercise.name,
                        color = TextPrimary,
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.height(3.dp))
                    Text(
                        text = "${exercise.targetMuscle} • ${exercise.sets} Sets × ${exercise.reps}",
                        color = AccentFrost,
                        fontSize = 11.sp,
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.SemiBold
                    )
                }

                if (allCompleted) {
                    Box(
                        modifier = Modifier
                            .clip(CircleShape)
                            .background(AccentToxic)
                            .padding(5.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Check,
                            contentDescription = "Done",
                            tint = Color.Black,
                            modifier = Modifier.size(14.dp)
                        )
                    }
                }
            }

            // Exercise Note (Hinglish Instruction)
            Spacer(modifier = Modifier.height(8.dp))
            Text(
                text = exercise.note,
                color = TextSecondary,
                fontSize = 12.sp,
                lineHeight = 17.sp
            )

            Spacer(modifier = Modifier.height(14.dp))

            // Actions row: MuscleWiki Video button + Set Checkers
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                // MuscleWiki Tutorial Button (Apple dark pill style)
                Row(
                    modifier = Modifier
                        .clip(RoundedCornerShape(999.dp))
                        .background(Color(0xFF282022))
                        .border(1.dp, AccentFlame.copy(alpha = 0.45f), RoundedCornerShape(999.dp))
                        .clickable { onWatchVideo() }
                        .padding(horizontal = 14.dp, vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = Icons.Default.PlayArrow,
                        contentDescription = "Play Video",
                        tint = AccentFlame,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(5.dp))
                    Text(
                        text = "MuscleWiki",
                        color = TextPrimary,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.SemiBold
                    )
                }

                // Set pills (1, 2, 3...)
                Row(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    for (setIndex in 0 until exercise.sets) {
                        val isDone = remember(setToggleTick) {
                            protocolPrefs.isSetCompleted(exercise.id, setIndex)
                        }

                        val setBgColor by animateColorAsState(
                            targetValue = if (isDone) AccentToxic else Color(0xFF252830),
                            animationSpec = spring(),
                            label = "set_bg"
                        )
                        val setScale by animateFloatAsState(
                            targetValue = if (isDone) 1.08f else 1.0f,
                            animationSpec = spring(dampingRatio = Spring.DampingRatioMediumBouncy),
                            label = "set_scale"
                        )

                        Box(
                            modifier = Modifier
                                .size(36.dp)
                                .scale(setScale)
                                .clip(RoundedCornerShape(12.dp))
                                .background(setBgColor)
                                .border(
                                    1.dp,
                                    if (isDone) AccentToxic else Color.White.copy(alpha = 0.14f),
                                    RoundedCornerShape(12.dp)
                                )
                                .clickable { onToggleSet(setIndex) },
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = "${setIndex + 1}",
                                color = if (isDone) Color.Black else TextPrimary,
                                fontSize = 12.sp,
                                fontFamily = FontFamily.Monospace,
                                fontWeight = FontWeight.ExtraBold
                            )
                        }
                    }
                }
            }
        }
    }
}
