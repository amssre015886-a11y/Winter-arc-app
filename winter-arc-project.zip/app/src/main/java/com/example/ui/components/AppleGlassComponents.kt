package com.example.ui.components

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.NorthEast
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.AccentFlame
import com.example.ui.theme.AccentFrost
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.theme.TextTertiary

/**
 * Consistent iOS 26 Neon Cyan specular border brush with top-left cyan rim lighting.
 */
fun appleSpecularBorderBrush(
    highlightColor: Color = AccentFrost.copy(alpha = 0.58f),
    midColor: Color = Color.White.copy(alpha = 0.22f),
    lowlightColor: Color = AccentFrost.copy(alpha = 0.24f)
): Brush = Brush.linearGradient(
    colors = listOf(
        highlightColor,
        midColor,
        lowlightColor
    )
)

/**
 * Reusable modifier for iOS 26 high-translucency obsidian glass cards with simulated high blur,
 * top cyan specular highlight line, and consistent neon cyan border.
 */
fun Modifier.ios26GlassCard(
    cornerRadius: Dp = 20.dp,
    baseColor: Color = Color(0x88080C16),
    glowColor: Color = AccentFrost,
    borderBrush: Brush = appleSpecularBorderBrush()
): Modifier = this
    .clip(RoundedCornerShape(cornerRadius))
    .drawBehind {
        // 1. Translucent obsidian base
        drawRect(color = baseColor)

        // 2. Frosted high-blur internal diffusion sheen
        drawRect(
            brush = Brush.linearGradient(
                colors = listOf(
                    Color.White.copy(alpha = 0.07f),
                    AccentFrost.copy(alpha = 0.03f),
                    Color.Transparent
                ),
                start = Offset(0f, 0f),
                end = Offset(size.width, size.height)
            )
        )

        // 3. Ambient corner glow
        drawCircle(
            brush = Brush.radialGradient(
                colors = listOf(
                    glowColor.copy(alpha = 0.16f),
                    glowColor.copy(alpha = 0.04f),
                    Color.Transparent
                ),
                center = Offset(size.width * 0.85f, size.height * 0.85f),
                radius = size.width * 0.72f
            ),
            center = Offset(size.width * 0.85f, size.height * 0.85f),
            radius = size.width * 0.72f
        )

        // 4. Top 1.dp neon cyan specular shine line
        drawLine(
            brush = Brush.horizontalGradient(
                colors = listOf(
                    Color.Transparent,
                    AccentFrost.copy(alpha = 0.65f),
                    Color.White.copy(alpha = 0.45f),
                    AccentFrost.copy(alpha = 0.65f),
                    Color.Transparent
                )
            ),
            start = Offset(size.width * 0.10f, 1.dp.toPx()),
            end = Offset(size.width * 0.90f, 1.dp.toPx()),
            strokeWidth = 1.2.dp.toPx()
        )
    }
    .border(1.dp, borderBrush, RoundedCornerShape(cornerRadius))

/**
 * High-density iOS 26 Bento Metric Card with translucent obsidian glass, neon cyan border,
 * and tick-mark ruler bar.
 */
@Composable
fun AppleBentoMetricCard(
    icon: ImageVector,
    title: String,
    subtitle: String,
    currentValueText: String,
    minLabel: String = "0",
    progress: Float,
    accentColor: Color = AccentFlame,
    onClick: (() -> Unit)? = null,
    modifier: Modifier = Modifier
) {
    val clampedProgress = progress.coerceIn(0f, 1f)
    val animatedProgress by animateFloatAsState(
        targetValue = clampedProgress,
        animationSpec = tween(durationMillis = 600, easing = FastOutSlowInEasing),
        label = "bento_ruler_progress"
    )

    Box(
        modifier = modifier
            .ios26GlassCard(
                cornerRadius = 20.dp,
                glowColor = accentColor,
                borderBrush = appleSpecularBorderBrush(
                    highlightColor = AccentFrost.copy(alpha = 0.62f),
                    midColor = accentColor.copy(alpha = 0.28f),
                    lowlightColor = AccentFrost.copy(alpha = 0.26f)
                )
            )
            .then(if (onClick != null) Modifier.clickable { onClick() } else Modifier)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp)
        ) {
            // Top Row: Squircle glass icon with cyan rim + expand arrow
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    modifier = Modifier
                        .size(30.dp)
                        .clip(RoundedCornerShape(9.dp))
                        .background(AccentFrost.copy(alpha = 0.10f))
                        .border(0.8.dp, AccentFrost.copy(alpha = 0.45f), RoundedCornerShape(9.dp)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = icon,
                        contentDescription = title,
                        tint = AccentFrost,
                        modifier = Modifier.size(15.dp)
                    )
                }

                Icon(
                    imageVector = Icons.Default.NorthEast,
                    contentDescription = null,
                    tint = AccentFrost.copy(alpha = 0.75f),
                    modifier = Modifier.size(14.dp)
                )
            }

            Spacer(modifier = Modifier.height(9.dp))

            // Title & Subtitle (tighter spacing)
            Text(
                text = title,
                color = TextPrimary,
                fontSize = 14.sp,
                fontWeight = FontWeight.Bold,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            Text(
                text = subtitle,
                color = TextSecondary,
                fontSize = 11.sp,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )

            Spacer(modifier = Modifier.height(10.dp))

            // Signature Tick-Mark Ruler Bar
            AppleTickRulerBar(
                progress = animatedProgress,
                accentColor = accentColor
            )

            Spacer(modifier = Modifier.height(6.dp))

            // Bottom Labels: "0" on left, neon value on right
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = minLabel,
                    color = TextTertiary,
                    fontSize = 10.sp,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.SemiBold
                )
                Text(
                    text = currentValueText,
                    color = accentColor,
                    fontSize = 11.sp,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.ExtraBold
                )
            }
        }
    }
}

/**
 * Sleek horizontal ruler progress bar with fine vertical ticks and a glowing white/cyan thumb.
 */
@Composable
fun AppleTickRulerBar(
    progress: Float,
    accentColor: Color = AccentFlame,
    modifier: Modifier = Modifier
) {
    val clamped = progress.coerceIn(0f, 1f)

    Box(
        modifier = modifier
            .fillMaxWidth()
            .height(20.dp)
            .clip(RoundedCornerShape(6.dp))
            .background(Color(0x8803050A))
            .border(0.8.dp, AccentFrost.copy(alpha = 0.28f), RoundedCornerShape(6.dp))
    ) {
        Canvas(modifier = Modifier.fillMaxSize()) {
            val w = size.width
            val h = size.height
            val fillWidth = (w * clamped).coerceAtLeast(4f)

            // 1. Gradient fill up to progress
            drawRoundRect(
                brush = Brush.horizontalGradient(
                    colors = listOf(
                        AccentFrost.copy(alpha = 0.14f),
                        accentColor.copy(alpha = 0.42f)
                    ),
                    startX = 0f,
                    endX = fillWidth
                ),
                size = Size(fillWidth, h),
                cornerRadius = CornerRadius(6.dp.toPx(), 6.dp.toPx())
            )

            // 2. Vertical ruler tick marks across the bar
            val tickCount = 24
            val horizontalPad = 6.dp.toPx()
            val usableWidth = (w - horizontalPad * 2).coerceAtLeast(1f)
            for (i in 0..tickCount) {
                val tx = horizontalPad + (i.toFloat() / tickCount) * usableWidth
                val isMajor = i % 4 == 0
                val tickHeight = if (isMajor) h * 0.50f else h * 0.30f
                val topY = (h - tickHeight) / 2f
                val isPassed = tx <= fillWidth
                drawLine(
                    color = if (isPassed) AccentFrost.copy(alpha = 0.55f) else Color.White.copy(alpha = 0.16f),
                    start = Offset(tx, topY),
                    end = Offset(tx, topY + tickHeight),
                    strokeWidth = 1.1.dp.toPx(),
                    cap = StrokeCap.Round
                )
            }

            // 3. Glowing vertical thumb indicator
            val thumbX = (horizontalPad + clamped * usableWidth).coerceIn(horizontalPad, w - horizontalPad)
            drawLine(
                color = accentColor.copy(alpha = 0.70f),
                start = Offset(thumbX, 2.dp.toPx()),
                end = Offset(thumbX, h - 2.dp.toPx()),
                strokeWidth = 5.dp.toPx(),
                cap = StrokeCap.Round
            )
            drawLine(
                color = Color.White,
                start = Offset(thumbX, 2.dp.toPx()),
                end = Offset(thumbX, h - 2.dp.toPx()),
                strokeWidth = 2.dp.toPx(),
                cap = StrokeCap.Round
            )
        }
    }
}

/**
 * Full-width Action Pill Button with neon cyan-rimmed outer border and left icon circle.
 */
@Composable
fun AppleOrangeActionPillButton(
    text: String,
    icon: ImageVector,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    enabled: Boolean = true
) {
    Box(
        modifier = modifier
            .fillMaxWidth()
            .height(48.dp)
            .clip(RoundedCornerShape(999.dp))
            .background(
                Brush.horizontalGradient(
                    colors = if (enabled) {
                        listOf(Color(0xFFFF6B24), Color(0xFFFF4E00))
                    } else {
                        listOf(Color(0xFF3B241A), Color(0xFF2B1912))
                    }
                )
            )
            .border(
                1.dp,
                Brush.horizontalGradient(
                    listOf(
                        AccentFrost.copy(alpha = 0.65f),
                        Color.White.copy(alpha = 0.35f),
                        AccentFrost.copy(alpha = 0.65f)
                    )
                ),
                RoundedCornerShape(999.dp)
            )
            .clickable(enabled = enabled) { onClick() }
            .padding(horizontal = 6.dp),
        contentAlignment = Alignment.Center
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Box(
                modifier = Modifier
                    .size(34.dp)
                    .clip(CircleShape)
                    .background(Color.Black.copy(alpha = 0.24f))
                    .border(0.8.dp, Color.White.copy(alpha = 0.30f), CircleShape),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = icon,
                    contentDescription = null,
                    tint = Color.White,
                    modifier = Modifier.size(17.dp)
                )
            }

            Text(
                text = text,
                color = Color.White,
                fontSize = 13.sp,
                fontWeight = FontWeight.ExtraBold,
                letterSpacing = 0.2.sp
            )

            Text(
                text = "›››",
                color = Color.White.copy(alpha = 0.90f),
                fontSize = 16.sp,
                fontWeight = FontWeight.Bold,
                letterSpacing = 1.sp,
                modifier = Modifier.padding(end = 8.dp)
            )
        }
    }
}

/**
 * Translucent cyan-rimmed live status badge.
 */
@Composable
fun AppleLiveStatusBadge(
    text: String,
    dotColor: Color = AccentFlame,
    modifier: Modifier = Modifier
) {
    Row(
        modifier = modifier
            .clip(RoundedCornerShape(999.dp))
            .background(Color(0x8C090D16))
            .border(0.8.dp, AccentFrost.copy(alpha = 0.45f), RoundedCornerShape(999.dp))
            .padding(horizontal = 9.dp, vertical = 4.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            modifier = Modifier
                .size(6.dp)
                .clip(CircleShape)
                .background(dotColor)
        )
        Spacer(modifier = Modifier.width(5.dp))
        Text(
            text = text,
            color = TextPrimary,
            fontSize = 10.sp,
            fontFamily = FontFamily.Monospace,
            fontWeight = FontWeight.Bold
        )
    }
}
