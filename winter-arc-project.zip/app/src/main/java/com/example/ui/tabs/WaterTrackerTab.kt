package com.example.ui.tabs

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Opacity
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Undo
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.clipPath
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.ProtocolPreferences
import com.example.ui.components.AudioChimeHelper
import com.example.ui.theme.AccentFlame
import com.example.ui.theme.AccentFrost
import com.example.ui.theme.AccentRed
import com.example.ui.theme.AccentToxic
import com.example.ui.theme.CardBackground
import com.example.ui.theme.CardBorder
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.theme.TextTertiary
import kotlin.math.sin

@Composable
fun WaterTrackerTab(
    protocolPrefs: ProtocolPreferences,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val currentWaterIntake by protocolPrefs.waterIntakeFlow.collectAsState()
    val targetWater = protocolPrefs.getWaterTarget() // 3500ml

    val fillRatio = (currentWaterIntake.toFloat() / targetWater).coerceIn(0f, 1f)
    val animatedFillRatio by animateFloatAsState(
        targetValue = fillRatio,
        animationSpec = tween(durationMillis = 650, easing = FastOutSlowInEasing),
        label = "water_fill"
    )

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(18.dp)
    ) {
        item {
            Spacer(modifier = Modifier.height(6.dp))

            // Header Banner
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(24.dp))
                    .background(CardBackground)
                    .border(1.dp, CardBorder, RoundedCornerShape(24.dp))
                    .padding(20.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = "JAL SANKALP // HYDRATION",
                            color = AccentFrost,
                            fontSize = 11.sp,
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.ExtraBold,
                            letterSpacing = 1.2.sp
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "Daily 3.5L Protocol",
                            color = TextPrimary,
                            fontSize = 22.sp,
                            fontWeight = FontWeight.ExtraBold
                        )
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(
                            text = "Muscle hydration is key for protein synthesis & joint recovery.",
                            color = TextSecondary,
                            fontSize = 12.sp
                        )
                    }
                    Icon(
                        imageVector = Icons.Default.Refresh,
                        contentDescription = "Reset Water",
                        tint = TextTertiary,
                        modifier = Modifier
                            .size(20.dp)
                            .clickable { protocolPrefs.resetWater() }
                    )
                }
            }
        }

        // Circular Animated Water Wave Sphere
        item {
            WaterSphere(
                currentMl = currentWaterIntake,
                targetMl = targetWater,
                fillRatio = animatedFillRatio
            )
        }

        // Quick Add Buttons Grid
        item {
            Column(modifier = Modifier.fillMaxWidth()) {
                Text(
                    text = "QUICK HYDRATION LOG",
                    color = TextTertiary,
                    fontSize = 11.sp,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 1.sp,
                    modifier = Modifier.padding(start = 4.dp, bottom = 8.dp)
                )

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    WaterButton(
                        label = "+250ml",
                        sub = "Glass",
                        modifier = Modifier.weight(1f),
                        onClick = {
                            protocolPrefs.addWater(250)
                            AudioChimeHelper.playWaterChime(context)
                        }
                    )
                    WaterButton(
                        label = "+500ml",
                        sub = "Bottle",
                        modifier = Modifier.weight(1f),
                        onClick = {
                            protocolPrefs.addWater(500)
                            AudioChimeHelper.playWaterChime(context)
                        }
                    )
                    WaterButton(
                        label = "+750ml",
                        sub = "Shaker",
                        modifier = Modifier.weight(1f),
                        onClick = {
                            protocolPrefs.addWater(750)
                            AudioChimeHelper.playWaterChime(context)
                        }
                    )
                    WaterUndoButton(
                        modifier = Modifier.weight(0.9f),
                        onClick = {
                            protocolPrefs.undoWater(250)
                            AudioChimeHelper.vibrate(context, 40)
                        }
                    )
                }
            }
        }

        // Hydration Milestones Card
        item {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(22.dp))
                    .background(CardBackground)
                    .border(1.dp, CardBorder, RoundedCornerShape(22.dp))
                    .padding(18.dp)
            ) {
                Column {
                    Text(
                        text = "HYDRATION MILESTONES",
                        color = AccentFrost,
                        fontSize = 11.sp,
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.ExtraBold,
                        letterSpacing = 1.sp
                    )
                    Spacer(modifier = Modifier.height(12.dp))

                    MilestoneRow(
                        title = "Morning Kickstart (1.0L)",
                        desc = "Wake up hydration & metabolism activation",
                        achieved = currentWaterIntake >= 1000
                    )
                    MilestoneRow(
                        title = "Mid-Day Performance (2.0L)",
                        desc = "Intra-workout hydration & cellular pump",
                        achieved = currentWaterIntake >= 2000
                    )
                    MilestoneRow(
                        title = "Winter Arc Target (3.5L)",
                        desc = "Optimal flushing, joint lubrication & recomp",
                        achieved = currentWaterIntake >= 3500
                    )
                }
            }
        }

        item {
            Spacer(modifier = Modifier.height(90.dp))
        }
    }
}

@Composable
fun WaterSphere(
    currentMl: Int,
    targetMl: Int,
    fillRatio: Float,
    modifier: Modifier = Modifier
) {
    val transition = rememberInfiniteTransition(label = "wave_anim")
    val wavePhase by transition.animateFloat(
        initialValue = 0f,
        targetValue = (2 * Math.PI).toFloat(),
        animationSpec = infiniteRepeatable(
            animation = tween(2400, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "phase"
    )

    Box(
        modifier = modifier
            .size(220.dp)
            .clip(CircleShape)
            .background(Color(0xFF0F172A).copy(alpha = 0.9f))
            .border(3.dp, AccentFrost.copy(alpha = 0.45f), CircleShape),
        contentAlignment = Alignment.Center
    ) {
        Canvas(modifier = Modifier.fillMaxSize()) {
            val width = size.width
            val height = size.height
            val radius = width / 2f
            val center = Offset(radius, radius)

            // Clip drawing inside sphere circle
            val circlePath = Path().apply {
                addOval(androidx.compose.ui.geometry.Rect(0f, 0f, width, height))
            }

            clipPath(circlePath) {
                // Background subtle water gradient
                val waterLevelY = height * (1f - fillRatio)
                val waveAmplitude = if (fillRatio in 0.02f..0.98f) 8.dp.toPx() else 2.dp.toPx()

                val wavePath = Path().apply {
                    moveTo(0f, height)
                    lineTo(0f, waterLevelY)

                    // Draw smooth sine wave across width
                    val steps = 30
                    for (i in 0..steps) {
                        val x = (i.toFloat() / steps) * width
                        val y = waterLevelY + sin((x / width) * 2 * Math.PI + wavePhase).toFloat() * waveAmplitude
                        lineTo(x, y)
                    }

                    lineTo(width, height)
                    close()
                }

                drawPath(
                    path = wavePath,
                    brush = Brush.verticalGradient(
                        colors = listOf(
                            AccentFrost.copy(alpha = 0.85f),
                            Color(0xFF0284C7).copy(alpha = 0.95f)
                        ),
                        startY = waterLevelY,
                        endY = height
                    )
                )
            }
        }

        // Inner Content
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Icon(
                imageVector = Icons.Default.Opacity,
                contentDescription = null,
                tint = if (fillRatio > 0.45f) Color.White else AccentFrost,
                modifier = Modifier.size(24.dp)
            )
            Spacer(modifier = Modifier.height(2.dp))
            Text(
                text = "${currentMl}ml",
                color = Color.White,
                fontSize = 30.sp,
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.Black
            )
            Text(
                text = "/ ${targetMl}ml TARGET",
                color = if (fillRatio > 0.5f) Color(0xFFE2E8F0) else AccentFrost,
                fontSize = 11.sp,
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.Bold,
                letterSpacing = 1.sp
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = "${(fillRatio * 100).toInt()}% Done",
                color = if (fillRatio >= 1f) AccentToxic else Color(0xFFFF8533),
                fontSize = 12.sp,
                fontWeight = FontWeight.ExtraBold
            )
        }
    }
}

@Composable
fun WaterButton(
    label: String,
    sub: String,
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    Box(
        modifier = modifier
            .clip(RoundedCornerShape(16.dp))
            .background(AccentFrost.copy(alpha = 0.12f))
            .border(1.dp, AccentFrost.copy(alpha = 0.3f), RoundedCornerShape(16.dp))
            .clickable { onClick() }
            .padding(vertical = 12.dp, horizontal = 6.dp),
        contentAlignment = Alignment.Center
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text(
                text = label,
                color = TextPrimary,
                fontSize = 14.sp,
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.ExtraBold
            )
            Text(
                text = sub,
                color = AccentFrost,
                fontSize = 10.sp,
                fontWeight = FontWeight.Bold
            )
        }
    }
}

@Composable
fun WaterUndoButton(
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    Box(
        modifier = modifier
            .clip(RoundedCornerShape(16.dp))
            .background(AccentRed.copy(alpha = 0.12f))
            .border(1.dp, AccentRed.copy(alpha = 0.28f), RoundedCornerShape(16.dp))
            .clickable { onClick() }
            .padding(vertical = 12.dp, horizontal = 6.dp),
        contentAlignment = Alignment.Center
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Icon(
                imageVector = Icons.Default.Undo,
                contentDescription = "Undo",
                tint = Color(0xFFF87171),
                modifier = Modifier.size(18.dp)
            )
            Text(
                text = "Undo",
                color = Color(0xFFF87171),
                fontSize = 10.sp,
                fontWeight = FontWeight.Bold
            )
        }
    }
}

@Composable
fun MilestoneRow(
    title: String,
    desc: String,
    achieved: Boolean
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = title,
                color = if (achieved) AccentToxic else TextPrimary,
                fontSize = 13.sp,
                fontWeight = FontWeight.Bold
            )
            Text(
                text = desc,
                color = TextTertiary,
                fontSize = 11.sp
            )
        }
        Box(
            modifier = Modifier
                .clip(RoundedCornerShape(8.dp))
                .background(if (achieved) AccentToxic.copy(alpha = 0.2f) else Color(0x0AFFFFFF))
                .padding(horizontal = 8.dp, vertical = 4.dp)
        ) {
            Text(
                text = if (achieved) "COMPLETED" else "PENDING",
                color = if (achieved) AccentToxic else TextTertiary,
                fontSize = 10.sp,
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.Bold
            )
        }
    }
}
