package com.example.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable

private val WinterArcColorScheme = darkColorScheme(
    primary = AccentFlame,
    onPrimary = ObsidianBlack,
    primaryContainer = AccentFlameGlow,
    onPrimaryContainer = TextPrimary,
    secondary = AccentFrost,
    onSecondary = ObsidianBlack,
    secondaryContainer = AccentFrostGlow,
    onSecondaryContainer = TextPrimary,
    tertiary = AccentToxic,
    onTertiary = ObsidianBlack,
    background = ObsidianBlack,
    onBackground = TextPrimary,
    surface = CardBackgroundSolid,
    onSurface = TextPrimary,
    surfaceVariant = GlassSurfaceDark,
    onSurfaceVariant = TextSecondary,
    outline = CardBorder
)

@Composable
fun WinterArcTheme(
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = WinterArcColorScheme,
        typography = Typography,
        content = content
    )
}
