package com.example.ui.tabs

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.spring
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Replay
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.ProtocolPreferences
import com.example.ui.components.AudioChimeHelper
import com.example.ui.theme.AccentFlame
import com.example.ui.theme.AccentFrost
import com.example.ui.theme.AccentToxic
import com.example.ui.theme.CardBackground
import com.example.ui.theme.CardBorder
import com.example.ui.theme.ObsidianBlack
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.theme.TextTertiary
import kotlinx.coroutines.delay

enum class TimerMode {
    REST_INTERVAL,
    TABATA_HIIT
}

@Composable
fun TimerConsoleTab(
    protocolPrefs: ProtocolPreferences,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    var mode by remember { mutableStateOf(TimerMode.REST_INTERVAL) }

    // Rest interval state
    var selectedPresetSeconds by remember { mutableStateOf(60) }
    var secondsRemaining by remember { mutableStateOf(60) }
    var isRunning by remember { mutableStateOf(false) }

    // Tabata state
    var tabataRound by remember { mutableStateOf(1) } // 1 to 8
    val tabataTotalRounds = 8
    var isTabataWorkPhase by remember { mutableStateOf(true) } // true = work (20s), false = rest (10s)
    var tabataSecondsRemaining by remember { mutableStateOf(20) }
    var isTabataRunning by remember { mutableStateOf(false) }

    // Countdown loop for regular rest timer
    LaunchedEffect(isRunning, secondsRemaining) {
        if (isRunning && secondsRemaining > 0) {
            delay(1000)
            val nextSec = secondsRemaining - 1
            secondsRemaining = nextSec
            if (nextSec in 1..3) {
                AudioChimeHelper.playCountdownBeep(context, isFinal = false)
            } else if (nextSec == 0) {
                AudioChimeHelper.playCountdownBeep(context, isFinal = true)
                isRunning = false
            }
        }
    }

    // Countdown loop for Tabata HIIT timer
    LaunchedEffect(isTabataRunning, tabataSecondsRemaining, isTabataWorkPhase, tabataRound) {
        if (isTabataRunning) {
            delay(1000)
            if (tabataSecondsRemaining > 1) {
                val next = tabataSecondsRemaining - 1
                tabataSecondsRemaining = next
                if (next in 1..3) {
                    AudioChimeHelper.playCountdownBeep(context, isFinal = false)
                }
            } else {
                // Phase completed!
                if (isTabataWorkPhase) {
                    // Transition to Rest Phase
                    isTabataWorkPhase = false
                    tabataSecondsRemaining = 10
                    AudioChimeHelper.playTabataPhaseChime(context, isWork = false)
                } else {
                    // Rest completed, move to next round
                    if (tabataRound < tabataTotalRounds) {
                        tabataRound++
                        isTabataWorkPhase = true
                        tabataSecondsRemaining = 20
                        AudioChimeHelper.playTabataPhaseChime(context, isWork = true)
                    } else {
                        // Finished all 8 rounds!
                        isTabataRunning = false
                        AudioChimeHelper.playCountdownBeep(context, isFinal = true)
                    }
                }
            }
        }
    }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Spacer(modifier = Modifier.height(6.dp))

            // Mode Switcher Header
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(18.dp))
                    .background(Color(0xD912141C))
                    .border(1.dp, CardBorder, RoundedCornerShape(18.dp))
                    .padding(4.dp),
                horizontalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                TimerModeButton(
                    label = "Rest Interval",
                    selected = mode == TimerMode.REST_INTERVAL,
                    modifier = Modifier.weight(1f),
                    onClick = {
                        isRunning = false
                        isTabataRunning = false
                        mode = TimerMode.REST_INTERVAL
                    }
                )
                TimerModeButton(
                    label = "Thursday Tabata HIIT",
                    selected = mode == TimerMode.TABATA_HIIT,
                    modifier = Modifier.weight(1f),
                    onClick = {
                        isRunning = false
                        isTabataRunning = false
                        mode = TimerMode.TABATA_HIIT
                    }
                )
            }
        }

        if (mode == TimerMode.REST_INTERVAL) {
            // Standard Rest Console Card
            item {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(26.dp))
                        .background(CardBackground)
                        .border(1.dp, CardBorder, RoundedCornerShape(26.dp))
                        .padding(24.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.VolumeUp,
                                contentDescription = null,
                                tint = AccentFrost,
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "AUDIO CHIMES ACTIVE",
                                color = AccentFrost,
                                fontSize = 11.sp,
                                fontFamily = FontFamily.Monospace,
                                fontWeight = FontWeight.Bold,
                                letterSpacing = 1.sp
                            )
                        }

                        Spacer(modifier = Modifier.height(12.dp))

                        // Large Digital Clock
                        val minutes = secondsRemaining / 60
                        val seconds = secondsRemaining % 60
                        val timeStr = String.format("%02d:%02d", minutes, seconds)

                        Text(
                            text = timeStr,
                            color = if (secondsRemaining == 0) AccentToxic else TextPrimary,
                            fontSize = 68.sp,
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.Black,
                            letterSpacing = (-2).sp
                        )

                        Text(
                            text = if (isRunning) "RECOVERY IN PROGRESS..." else "READY FOR NEXT SET",
                            color = if (isRunning) AccentFlame else TextTertiary,
                            fontSize = 12.sp,
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.Bold
                        )

                        Spacer(modifier = Modifier.height(20.dp))

                        // Interval Presets
                        Row(
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            listOf(30, 60, 90, 120).forEach { sec ->
                                val isSelected = selectedPresetSeconds == sec
                                val pillBg by animateColorAsState(
                                    targetValue = if (isSelected) AccentFlame else Color(0x0AFFFFFF),
                                    animationSpec = spring(),
                                    label = "preset_pill"
                                )
                                Box(
                                    modifier = Modifier
                                        .weight(1f)
                                        .clip(RoundedCornerShape(999.dp))
                                        .background(pillBg)
                                        .border(
                                            1.dp,
                                            if (isSelected) AccentFlame else Color(0x14FFFFFF),
                                            RoundedCornerShape(999.dp)
                                        )
                                        .clickable {
                                            selectedPresetSeconds = sec
                                            secondsRemaining = sec
                                            isRunning = false
                                        }
                                        .padding(vertical = 10.dp),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text(
                                        text = "${sec}s",
                                        color = if (isSelected) Color.Black else TextSecondary,
                                        fontSize = 12.sp,
                                        fontFamily = FontFamily.Monospace,
                                        fontWeight = FontWeight.ExtraBold
                                    )
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(24.dp))

                        // Action Buttons: Play/Pause, Reset, +15s
                        Row(
                            horizontalArrangement = Arrangement.spacedBy(12.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            // Reset
                            Box(
                                modifier = Modifier
                                    .size(50.dp)
                                    .clip(CircleShape)
                                    .background(Color(0x14FFFFFF))
                                    .border(1.dp, Color(0x22FFFFFF), CircleShape)
                                    .clickable {
                                        isRunning = false
                                        secondsRemaining = selectedPresetSeconds
                                    },
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Replay,
                                    contentDescription = "Reset",
                                    tint = TextSecondary,
                                    modifier = Modifier.size(20.dp)
                                )
                            }

                            // Start / Pause Main Button
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(999.dp))
                                    .background(if (isRunning) Color(0xFFEF4444) else AccentFlame)
                                    .clickable {
                                        if (secondsRemaining == 0) secondsRemaining = selectedPresetSeconds
                                        isRunning = !isRunning
                                    }
                                    .padding(horizontal = 36.dp, vertical = 14.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(
                                        imageVector = if (isRunning) Icons.Default.Pause else Icons.Default.PlayArrow,
                                        contentDescription = null,
                                        tint = if (isRunning) Color.White else Color.Black,
                                        modifier = Modifier.size(20.dp)
                                    )
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text(
                                        text = if (isRunning) "PAUSE" else "START REST",
                                        color = if (isRunning) Color.White else Color.Black,
                                        fontSize = 14.sp,
                                        fontWeight = FontWeight.ExtraBold,
                                        letterSpacing = 0.5.sp
                                    )
                                }
                            }

                            // +15s quick add
                            Box(
                                modifier = Modifier
                                    .size(50.dp)
                                    .clip(CircleShape)
                                    .background(Color(0x14FFFFFF))
                                    .border(1.dp, Color(0x22FFFFFF), CircleShape)
                                    .clickable {
                                        secondsRemaining += 15
                                    },
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = "+15",
                                    color = AccentFrost,
                                    fontSize = 12.sp,
                                    fontFamily = FontFamily.Monospace,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    }
                }
            }
        } else {
            // Tabata HIIT Mode Console
            item {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(26.dp))
                        .background(CardBackground)
                        .border(
                            1.dp,
                            if (isTabataWorkPhase) AccentFlame.copy(alpha = 0.5f) else AccentFrost.copy(alpha = 0.5f),
                            RoundedCornerShape(26.dp)
                        )
                        .padding(24.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        // Phase Tag Pill
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(999.dp))
                                .background(
                                    if (isTabataWorkPhase) AccentFlame.copy(alpha = 0.2f) else AccentFrost.copy(alpha = 0.2f)
                                )
                                .border(
                                    1.dp,
                                    if (isTabataWorkPhase) AccentFlame else AccentFrost,
                                    RoundedCornerShape(999.dp)
                                )
                                .padding(horizontal = 16.dp, vertical = 6.dp)
                        ) {
                            Text(
                                text = if (isTabataWorkPhase) "🔥 WORK PHASE (MAX EFFORT)" else "❄️ REST PHASE (BREATHE)",
                                color = if (isTabataWorkPhase) AccentFlame else AccentFrost,
                                fontSize = 11.sp,
                                fontFamily = FontFamily.Monospace,
                                fontWeight = FontWeight.ExtraBold,
                                letterSpacing = 1.sp
                            )
                        }

                        Spacer(modifier = Modifier.height(16.dp))

                        // Tabata Countdown Big Clock
                        Text(
                            text = "${tabataSecondsRemaining}s",
                            color = if (isTabataWorkPhase) AccentFlame else AccentFrost,
                            fontSize = 72.sp,
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.Black
                        )

                        Spacer(modifier = Modifier.height(6.dp))

                        Text(
                            text = "ROUND $tabataRound OF $tabataTotalRounds",
                            color = TextPrimary,
                            fontSize = 14.sp,
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.Bold
                        )

                        Spacer(modifier = Modifier.height(24.dp))

                        // Controls
                        Row(
                            horizontalArrangement = Arrangement.spacedBy(16.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            // Reset
                            Box(
                                modifier = Modifier
                                    .size(50.dp)
                                    .clip(CircleShape)
                                    .background(Color(0x14FFFFFF))
                                    .border(1.dp, Color(0x22FFFFFF), CircleShape)
                                    .clickable {
                                        isTabataRunning = false
                                        tabataRound = 1
                                        isTabataWorkPhase = true
                                        tabataSecondsRemaining = 20
                                    },
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Replay,
                                    contentDescription = "Reset Tabata",
                                    tint = TextSecondary,
                                    modifier = Modifier.size(20.dp)
                                )
                            }

                            // Start / Stop Tabata
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(999.dp))
                                    .background(if (isTabataRunning) Color(0xFFEF4444) else AccentFlame)
                                    .clickable {
                                        isTabataRunning = !isTabataRunning
                                        if (isTabataRunning) {
                                            AudioChimeHelper.playTabataPhaseChime(context, isTabataWorkPhase)
                                        }
                                    }
                                    .padding(horizontal = 38.dp, vertical = 14.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = if (isTabataRunning) "PAUSE HIIT" else "START TABATA",
                                    color = if (isTabataRunning) Color.White else Color.Black,
                                    fontSize = 14.sp,
                                    fontWeight = FontWeight.ExtraBold,
                                    letterSpacing = 0.5.sp
                                )
                            }
                        }
                    }
                }
            }
        }

        // Rest Guidelines Card
        item {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(22.dp))
                    .background(CardBackground)
                    .border(1.dp, CardBorder, RoundedCornerShape(22.dp))
                    .padding(18.dp)
            ) {
                Column {
                    Text(
                        text = "REST INTERVAL SCIENCE",
                        color = AccentFlame,
                        fontSize = 11.sp,
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.ExtraBold,
                        letterSpacing = 1.sp
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "• Heavy Compounds (Squats, Deadlifts, Bench): 90s - 120s rest for ATP regeneration.\n• Isolation & Accessories (Lateral Raises, Arms, Calves): 45s - 60s for maximum hypertrophy metabolic stress.\n• Thursday Tabata: 20s burst / 10s breathe. Audio beeps signal transition automatically.",
                        color = TextSecondary,
                        fontSize = 12.sp,
                        lineHeight = 18.sp
                    )
                }
            }
        }

        item {
            Spacer(modifier = Modifier.height(90.dp))
        }
    }
}

@Composable
fun TimerModeButton(
    label: String,
    selected: Boolean,
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    val bgColor by animateColorAsState(
        targetValue = if (selected) AccentFlame else Color.Transparent,
        animationSpec = spring(),
        label = "mode_btn_bg"
    )

    Box(
        modifier = modifier
            .clip(RoundedCornerShape(14.dp))
            .background(bgColor)
            .clickable { onClick() }
            .padding(vertical = 10.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = label,
            color = if (selected) Color.Black else TextSecondary,
            fontSize = 12.sp,
            fontFamily = FontFamily.Monospace,
            fontWeight = FontWeight.Bold
        )
    }
}
